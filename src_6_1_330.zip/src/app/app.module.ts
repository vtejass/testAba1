import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Router } from "@angular/router";
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutes,AppComponents} from './app.routing';
import { FormsModule } from '@angular/forms';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { loginService } from './serverData/login.service';
import { customerDetailsService } from './serverData/customerDetails.service';

@NgModule({
  imports:[BrowserModule,RouterModule,RouterModule.forRoot(AppRoutes),FormsModule,ReactiveFormsModule,HttpModule,BsDropdownModule.forRoot()],
  declarations:[AppComponent,AppComponents],
  providers:[loginService,customerDetailsService],
  bootstrap:[AppComponent]
})
export class AppModule { }
