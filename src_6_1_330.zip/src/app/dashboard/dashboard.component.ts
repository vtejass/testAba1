import { Component,OnInit } from '@angular/core';
@Component({
    selector: 'dashboard',
    templateUrl: './dashboard.html',
    styleUrls:['./dashboard.style.css']
  })
  
  export class DashBoardComponent  implements OnInit{
    loggedName:string;
    ngOnInit(){
      this.loggedName = sessionStorage.getItem("fullName");
      //alert(this.loggedName);
    }
  }