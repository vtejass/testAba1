import { DashBoardComponent }  from './dashboard/dashboard.component';
import { LoginComponent }  from './login/login.component';
import {CustomerComponent} from './dashboard/customers/customer.component';
import {dashboardbody} from './dashboard/dashboardBody/dashboardBody.component';

export const AppComponents: any = [
    DashBoardComponent,
    LoginComponent,
    CustomerComponent,
    dashboardbody
];
export const AppRoutes: any = [
    {path :'',component:LoginComponent},
    { path: "dashboard", component: DashBoardComponent,children:[
       { path :'customers',component:CustomerComponent,outlet:'dashboardRoute'},
       { path :'',  component: dashboardbody,outlet:'dashboardRoute'}
    ] }
];