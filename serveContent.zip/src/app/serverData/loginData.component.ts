export class loginData{
    constructor(
       /* public accessToken:string,
        public statusCode:string,
        public statusDescription:string,*/
        public username:string,
        public password:string
    ){}
}