import { Component } from '@angular/core';
@Component({
    selector: 'dashboard',
    templateUrl: './dashboard.html',
    styleUrls:['./dashboard.style.css']
  })
  
  export class DashBoardComponent{
   
  }