import { Component } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import {Injectable} from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Router } from "@angular/router";
import { FormControl, FormGroup, Validators, FormBuilder  } from '@angular/forms';

import {customerDetailsService} from '../../serverData/customerDetails.service';
@Component({
    selector:'customer',
    templateUrl:'./customers.html',
    styleUrls:['./customers.css']
})
export class CustomerComponent {
    users:any;
    searchCustomerName = new FormControl('',[]);
    searchPsuid = new FormControl('',[]);
    searchControlnumber = new FormControl('',[]);
    searchStatus = new FormControl('',[]);
    searchEffectiveDate = new FormControl('',[]);

    searchCustomersForm: FormGroup = this.builder.group({
      searchCustomerName: this.searchCustomerName,
      searchPsuid: this.searchPsuid,
      searchControlnumber: this.searchControlnumber,
      searchStatus: this.searchStatus,
      searchEffectiveDate: this.searchEffectiveDate
    });
    constructor(private userService: customerDetailsService,private builder:FormBuilder) {
        this.users = userService.getUsers();
     }
     searchCustomers(){
         this.users = this.userService.getUsers();
         console.log(this.users)
     }
}