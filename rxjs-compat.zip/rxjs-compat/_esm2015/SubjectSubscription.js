export { SubjectSubscription } from 'rxjs/internal-compatibility';
//# sourceMappingURL=SubjectSubscription.js.map