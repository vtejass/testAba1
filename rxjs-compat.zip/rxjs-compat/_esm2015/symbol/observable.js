export { observable } from 'rxjs/internal-compatibility';
//# sourceMappingURL=observable.js.map