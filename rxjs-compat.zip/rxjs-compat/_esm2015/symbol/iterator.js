export { iterator } from 'rxjs/internal-compatibility';
//# sourceMappingURL=iterator.js.map