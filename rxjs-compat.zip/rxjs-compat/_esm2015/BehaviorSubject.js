export { BehaviorSubject } from 'rxjs';
//# sourceMappingURL=BehaviorSubject.js.map