export { isFunction } from 'rxjs/internal-compatibility';
//# sourceMappingURL=isFunction.js.map