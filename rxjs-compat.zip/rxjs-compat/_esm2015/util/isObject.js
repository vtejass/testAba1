export { isObject } from 'rxjs/internal-compatibility';
//# sourceMappingURL=isObject.js.map