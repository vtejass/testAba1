export { subscribeTo } from 'rxjs/internal-compatibility';
//# sourceMappingURL=subscribeTo.js.map