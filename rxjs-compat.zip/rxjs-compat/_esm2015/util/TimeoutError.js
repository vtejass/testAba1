export { TimeoutError } from 'rxjs/internal-compatibility';
//# sourceMappingURL=TimeoutError.js.map