export { subscribeToResult } from 'rxjs/internal-compatibility';
//# sourceMappingURL=subscribeToResult.js.map