export { isScheduler } from 'rxjs/internal-compatibility';
//# sourceMappingURL=isScheduler.js.map