export { isObservable } from 'rxjs/internal-compatibility';
//# sourceMappingURL=isObservable.js.map