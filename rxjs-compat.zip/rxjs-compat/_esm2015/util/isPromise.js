export { isPromise } from 'rxjs/internal-compatibility';
//# sourceMappingURL=isPromise.js.map