export { UnsubscriptionError } from 'rxjs/internal-compatibility';
//# sourceMappingURL=UnsubscriptionError.js.map