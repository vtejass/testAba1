export { pipe } from 'rxjs/internal-compatibility';
//# sourceMappingURL=pipe.js.map