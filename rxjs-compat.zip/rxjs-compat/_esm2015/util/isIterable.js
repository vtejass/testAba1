export { isIterable } from 'rxjs/internal-compatibility';
//# sourceMappingURL=isIterable.js.map