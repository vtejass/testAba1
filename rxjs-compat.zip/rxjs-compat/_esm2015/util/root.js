export { root } from 'rxjs/internal-compatibility';
//# sourceMappingURL=root.js.map