export { isDate } from 'rxjs/internal-compatibility';
//# sourceMappingURL=isDate.js.map