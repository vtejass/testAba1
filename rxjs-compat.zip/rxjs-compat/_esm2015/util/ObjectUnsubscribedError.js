export { ObjectUnsubscribedError } from 'rxjs/internal-compatibility';
//# sourceMappingURL=ObjectUnsubscribedError.js.map