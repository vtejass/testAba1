export { identity } from 'rxjs/internal-compatibility';
//# sourceMappingURL=identity.js.map