export { isArray } from 'rxjs/internal-compatibility';
//# sourceMappingURL=isArray.js.map