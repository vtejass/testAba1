export { EmptyError } from 'rxjs/internal-compatibility';
//# sourceMappingURL=EmptyError.js.map