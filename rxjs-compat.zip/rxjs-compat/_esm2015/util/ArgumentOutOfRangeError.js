export { ArgumentOutOfRangeError } from 'rxjs/internal-compatibility';
//# sourceMappingURL=ArgumentOutOfRangeError.js.map