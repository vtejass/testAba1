export { hostReportError } from 'rxjs/internal-compatibility';
//# sourceMappingURL=hostReportError.js.map