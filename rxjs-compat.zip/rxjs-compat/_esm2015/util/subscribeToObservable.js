export { subscribeToObservable } from 'rxjs/internal-compatibility';
//# sourceMappingURL=subscribeToObservable.js.map