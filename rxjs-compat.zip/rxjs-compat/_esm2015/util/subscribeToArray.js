export { subscribeToArray } from 'rxjs/internal-compatibility';
//# sourceMappingURL=subscribeToArray.js.map