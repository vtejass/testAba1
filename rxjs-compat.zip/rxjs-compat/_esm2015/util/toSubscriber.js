export { toSubscriber } from 'rxjs/internal-compatibility';
//# sourceMappingURL=toSubscriber.js.map