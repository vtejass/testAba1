export { errorObject } from 'rxjs/internal-compatibility';
//# sourceMappingURL=errorObject.js.map