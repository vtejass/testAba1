export { isNumeric } from 'rxjs/internal-compatibility';
//# sourceMappingURL=isNumeric.js.map