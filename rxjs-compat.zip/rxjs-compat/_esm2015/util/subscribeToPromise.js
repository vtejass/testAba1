export { subscribeToPromise } from 'rxjs/internal-compatibility';
//# sourceMappingURL=subscribeToPromise.js.map