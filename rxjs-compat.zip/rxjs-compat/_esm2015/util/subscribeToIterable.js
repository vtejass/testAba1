export { subscribeToIterable } from 'rxjs/internal-compatibility';
//# sourceMappingURL=subscribeToIterable.js.map