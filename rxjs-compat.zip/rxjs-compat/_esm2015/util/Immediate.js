export { Immediate } from 'rxjs/internal-compatibility';
//# sourceMappingURL=Immediate.js.map