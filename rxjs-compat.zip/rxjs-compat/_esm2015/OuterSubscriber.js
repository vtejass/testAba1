export { OuterSubscriber } from 'rxjs/internal-compatibility';
//# sourceMappingURL=OuterSubscriber.js.map