/**
 * @param func
 * @return {Observable<R>}
 * @method let
 * @owner Observable
 */
export function letProto(func) {
    return func(this);
}
//# sourceMappingURL=let.js.map