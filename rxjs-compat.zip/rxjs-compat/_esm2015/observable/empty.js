export { empty } from 'rxjs';
//# sourceMappingURL=empty.js.map