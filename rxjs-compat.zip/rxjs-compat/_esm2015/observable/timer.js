export { timer } from 'rxjs';
//# sourceMappingURL=timer.js.map