export { from as fromPromise } from 'rxjs';
//# sourceMappingURL=fromPromise.js.map