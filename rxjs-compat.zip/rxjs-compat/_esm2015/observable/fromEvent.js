export { fromEvent } from 'rxjs';
//# sourceMappingURL=fromEvent.js.map