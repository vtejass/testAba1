export { of } from 'rxjs';
//# sourceMappingURL=of.js.map