export { defer } from 'rxjs';
//# sourceMappingURL=defer.js.map