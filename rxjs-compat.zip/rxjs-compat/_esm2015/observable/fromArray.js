export { from as fromArray } from 'rxjs';
//# sourceMappingURL=fromArray.js.map