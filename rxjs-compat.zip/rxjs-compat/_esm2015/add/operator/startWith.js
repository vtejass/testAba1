import { Observable } from 'rxjs';
import { startWith } from '../../operator/startWith';
Observable.prototype.startWith = startWith;
//# sourceMappingURL=startWith.js.map