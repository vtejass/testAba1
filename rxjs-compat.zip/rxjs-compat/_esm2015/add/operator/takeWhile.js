import { Observable } from 'rxjs';
import { takeWhile } from '../../operator/takeWhile';
Observable.prototype.takeWhile = takeWhile;
//# sourceMappingURL=takeWhile.js.map