import { Observable } from 'rxjs';
import { last } from '../../operator/last';
Observable.prototype.last = last;
//# sourceMappingURL=last.js.map