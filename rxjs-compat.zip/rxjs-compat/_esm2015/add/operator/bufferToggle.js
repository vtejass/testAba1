import { Observable } from 'rxjs';
import { bufferToggle } from '../../operator/bufferToggle';
Observable.prototype.bufferToggle = bufferToggle;
//# sourceMappingURL=bufferToggle.js.map