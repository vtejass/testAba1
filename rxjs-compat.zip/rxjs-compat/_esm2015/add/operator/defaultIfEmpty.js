import { Observable } from 'rxjs';
import { defaultIfEmpty } from '../../operator/defaultIfEmpty';
Observable.prototype.defaultIfEmpty = defaultIfEmpty;
//# sourceMappingURL=defaultIfEmpty.js.map