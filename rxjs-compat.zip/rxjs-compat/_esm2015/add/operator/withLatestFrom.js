import { Observable } from 'rxjs';
import { withLatestFrom } from '../../operator/withLatestFrom';
Observable.prototype.withLatestFrom = withLatestFrom;
//# sourceMappingURL=withLatestFrom.js.map