import { Observable } from 'rxjs';
import { dematerialize } from '../../operator/dematerialize';
Observable.prototype.dematerialize = dematerialize;
//# sourceMappingURL=dematerialize.js.map