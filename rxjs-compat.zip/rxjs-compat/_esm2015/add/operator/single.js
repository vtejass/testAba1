import { Observable } from 'rxjs';
import { single } from '../../operator/single';
Observable.prototype.single = single;
//# sourceMappingURL=single.js.map