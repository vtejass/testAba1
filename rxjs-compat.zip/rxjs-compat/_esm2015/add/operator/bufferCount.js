import { Observable } from 'rxjs';
import { bufferCount } from '../../operator/bufferCount';
Observable.prototype.bufferCount = bufferCount;
//# sourceMappingURL=bufferCount.js.map