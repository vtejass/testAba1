import { Observable } from 'rxjs';
import { sample } from '../../operator/sample';
Observable.prototype.sample = sample;
//# sourceMappingURL=sample.js.map