import { Observable } from 'rxjs';
import { debounceTime } from '../../operator/debounceTime';
Observable.prototype.debounceTime = debounceTime;
//# sourceMappingURL=debounceTime.js.map