import { Observable } from 'rxjs';
import { pairwise } from '../../operator/pairwise';
Observable.prototype.pairwise = pairwise;
//# sourceMappingURL=pairwise.js.map