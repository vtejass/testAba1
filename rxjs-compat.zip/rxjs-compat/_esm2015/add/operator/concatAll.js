import { Observable } from 'rxjs';
import { concatAll } from '../../operator/concatAll';
Observable.prototype.concatAll = concatAll;
//# sourceMappingURL=concatAll.js.map