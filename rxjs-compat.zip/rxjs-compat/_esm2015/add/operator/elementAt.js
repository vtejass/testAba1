import { Observable } from 'rxjs';
import { elementAt } from '../../operator/elementAt';
Observable.prototype.elementAt = elementAt;
//# sourceMappingURL=elementAt.js.map