import { Observable } from 'rxjs';
import { filter } from '../../operator/filter';
Observable.prototype.filter = filter;
//# sourceMappingURL=filter.js.map