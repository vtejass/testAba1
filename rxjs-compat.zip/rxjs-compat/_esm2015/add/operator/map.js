import { Observable } from 'rxjs';
import { map } from '../../operator/map';
Observable.prototype.map = map;
//# sourceMappingURL=map.js.map