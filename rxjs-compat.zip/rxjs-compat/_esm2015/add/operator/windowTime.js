import { Observable } from 'rxjs';
import { windowTime } from '../../operator/windowTime';
Observable.prototype.windowTime = windowTime;
//# sourceMappingURL=windowTime.js.map