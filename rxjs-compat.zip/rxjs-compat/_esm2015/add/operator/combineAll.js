import { Observable } from 'rxjs';
import { combineAll } from '../../operator/combineAll';
Observable.prototype.combineAll = combineAll;
//# sourceMappingURL=combineAll.js.map