import { Observable } from 'rxjs';
import { distinct } from '../../operator/distinct';
Observable.prototype.distinct = distinct;
//# sourceMappingURL=distinct.js.map