import { Observable } from 'rxjs';
import { share } from '../../operator/share';
Observable.prototype.share = share;
//# sourceMappingURL=share.js.map