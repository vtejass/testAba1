import { Observable } from 'rxjs';
import { concat } from '../../operator/concat';
Observable.prototype.concat = concat;
//# sourceMappingURL=concat.js.map