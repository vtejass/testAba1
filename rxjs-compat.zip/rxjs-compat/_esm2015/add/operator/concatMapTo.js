import { Observable } from 'rxjs';
import { concatMapTo } from '../../operator/concatMapTo';
Observable.prototype.concatMapTo = concatMapTo;
//# sourceMappingURL=concatMapTo.js.map