import { Observable } from 'rxjs';
import { mergeScan } from '../../operator/mergeScan';
Observable.prototype.mergeScan = mergeScan;
//# sourceMappingURL=mergeScan.js.map