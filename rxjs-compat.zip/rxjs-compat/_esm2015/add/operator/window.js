import { Observable } from 'rxjs';
import { window } from '../../operator/window';
Observable.prototype.window = window;
//# sourceMappingURL=window.js.map