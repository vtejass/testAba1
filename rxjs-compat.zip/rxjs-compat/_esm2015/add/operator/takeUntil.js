import { Observable } from 'rxjs';
import { takeUntil } from '../../operator/takeUntil';
Observable.prototype.takeUntil = takeUntil;
//# sourceMappingURL=takeUntil.js.map