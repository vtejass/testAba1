import { Observable } from 'rxjs';
import { publishBehavior } from '../../operator/publishBehavior';
Observable.prototype.publishBehavior = publishBehavior;
//# sourceMappingURL=publishBehavior.js.map