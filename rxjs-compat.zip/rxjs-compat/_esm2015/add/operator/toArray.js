import { Observable } from 'rxjs';
import { toArray } from '../../operator/toArray';
Observable.prototype.toArray = toArray;
//# sourceMappingURL=toArray.js.map