import { Observable } from 'rxjs';
import { switchMapTo } from '../../operator/switchMapTo';
Observable.prototype.switchMapTo = switchMapTo;
//# sourceMappingURL=switchMapTo.js.map