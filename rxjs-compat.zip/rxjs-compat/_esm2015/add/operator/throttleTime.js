import { Observable } from 'rxjs';
import { throttleTime } from '../../operator/throttleTime';
Observable.prototype.throttleTime = throttleTime;
//# sourceMappingURL=throttleTime.js.map