import { Observable } from 'rxjs';
import { letProto } from '../../operator/let';
Observable.prototype.let = letProto;
Observable.prototype.letBind = letProto;
//# sourceMappingURL=let.js.map