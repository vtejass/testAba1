import { Observable } from 'rxjs';
import { publishLast } from '../../operator/publishLast';
Observable.prototype.publishLast = publishLast;
//# sourceMappingURL=publishLast.js.map