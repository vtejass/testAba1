import { Observable } from 'rxjs';
import { bufferTime } from '../../operator/bufferTime';
Observable.prototype.bufferTime = bufferTime;
//# sourceMappingURL=bufferTime.js.map