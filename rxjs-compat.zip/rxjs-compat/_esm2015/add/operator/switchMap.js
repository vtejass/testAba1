import { Observable } from 'rxjs';
import { switchMap } from '../../operator/switchMap';
Observable.prototype.switchMap = switchMap;
//# sourceMappingURL=switchMap.js.map