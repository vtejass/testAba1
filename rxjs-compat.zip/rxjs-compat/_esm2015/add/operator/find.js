import { Observable } from 'rxjs';
import { find } from '../../operator/find';
Observable.prototype.find = find;
//# sourceMappingURL=find.js.map