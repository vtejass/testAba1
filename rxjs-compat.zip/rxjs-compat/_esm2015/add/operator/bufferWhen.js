import { Observable } from 'rxjs';
import { bufferWhen } from '../../operator/bufferWhen';
Observable.prototype.bufferWhen = bufferWhen;
//# sourceMappingURL=bufferWhen.js.map