import { Observable } from 'rxjs';
import { isEmpty } from '../../operator/isEmpty';
Observable.prototype.isEmpty = isEmpty;
//# sourceMappingURL=isEmpty.js.map