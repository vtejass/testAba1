import { Observable } from 'rxjs';
import { audit } from '../../operator/audit';
Observable.prototype.audit = audit;
//# sourceMappingURL=audit.js.map