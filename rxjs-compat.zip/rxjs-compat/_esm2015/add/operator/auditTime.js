import { Observable } from 'rxjs';
import { auditTime } from '../../operator/auditTime';
Observable.prototype.auditTime = auditTime;
//# sourceMappingURL=auditTime.js.map