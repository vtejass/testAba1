import { Observable } from 'rxjs';
import { mergeAll } from '../../operator/mergeAll';
Observable.prototype.mergeAll = mergeAll;
//# sourceMappingURL=mergeAll.js.map