import { Observable } from 'rxjs';
import { race } from '../../operator/race';
Observable.prototype.race = race;
//# sourceMappingURL=race.js.map