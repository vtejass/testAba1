import { Observable } from 'rxjs';
import { throttle } from '../../operator/throttle';
Observable.prototype.throttle = throttle;
//# sourceMappingURL=throttle.js.map