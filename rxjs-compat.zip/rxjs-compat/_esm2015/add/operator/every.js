import { Observable } from 'rxjs';
import { every } from '../../operator/every';
Observable.prototype.every = every;
//# sourceMappingURL=every.js.map