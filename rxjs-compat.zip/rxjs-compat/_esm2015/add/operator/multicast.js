import { Observable } from 'rxjs';
import { multicast } from '../../operator/multicast';
Observable.prototype.multicast = multicast;
//# sourceMappingURL=multicast.js.map