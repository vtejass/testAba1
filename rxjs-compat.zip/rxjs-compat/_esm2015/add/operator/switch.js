import { Observable } from 'rxjs';
import { _switch } from '../../operator/switch';
Observable.prototype.switch = _switch;
Observable.prototype._switch = _switch;
//# sourceMappingURL=switch.js.map