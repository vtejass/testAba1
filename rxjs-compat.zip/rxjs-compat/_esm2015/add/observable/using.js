import { Observable, using as staticUsing } from 'rxjs';
Observable.using = staticUsing;
//# sourceMappingURL=using.js.map