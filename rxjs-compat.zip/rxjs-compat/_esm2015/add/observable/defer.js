import { Observable, defer as staticDefer } from 'rxjs';
Observable.defer = staticDefer;
//# sourceMappingURL=defer.js.map