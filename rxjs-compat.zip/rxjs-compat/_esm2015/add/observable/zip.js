import { Observable, zip as zipStatic } from 'rxjs';
Observable.zip = zipStatic;
//# sourceMappingURL=zip.js.map