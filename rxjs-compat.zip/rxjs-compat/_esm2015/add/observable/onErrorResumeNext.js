import { Observable, onErrorResumeNext as staticOnErrorResumeNext } from 'rxjs';
Observable.onErrorResumeNext = staticOnErrorResumeNext;
//# sourceMappingURL=onErrorResumeNext.js.map