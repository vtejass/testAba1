import { Observable, combineLatest as combineLatestStatic } from 'rxjs';
Observable.combineLatest = combineLatestStatic;
//# sourceMappingURL=combineLatest.js.map