import { Observable, fromEvent as staticFromEvent } from 'rxjs';
Observable.fromEvent = staticFromEvent;
//# sourceMappingURL=fromEvent.js.map