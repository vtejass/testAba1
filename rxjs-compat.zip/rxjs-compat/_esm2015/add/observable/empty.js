import { Observable, empty as staticEmpty } from 'rxjs';
Observable.empty = staticEmpty;
//# sourceMappingURL=empty.js.map