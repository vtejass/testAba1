import { Observable, generate as staticGenerate } from 'rxjs';
Observable.generate = staticGenerate;
//# sourceMappingURL=generate.js.map