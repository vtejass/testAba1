import { Observable, bindCallback as staticBindCallback } from 'rxjs';
Observable.bindCallback = staticBindCallback;
//# sourceMappingURL=bindCallback.js.map