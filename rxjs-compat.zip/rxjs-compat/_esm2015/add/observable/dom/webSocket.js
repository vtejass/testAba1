import { Observable } from 'rxjs';
import { webSocket as staticWebSocket } from 'rxjs/webSocket';
Observable.webSocket = staticWebSocket;
//# sourceMappingURL=webSocket.js.map