import { Observable, forkJoin as staticForkJoin } from 'rxjs';
Observable.forkJoin = staticForkJoin;
//# sourceMappingURL=forkJoin.js.map