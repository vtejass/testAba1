import { Observable, iif } from 'rxjs';
Observable.if = iif;
//# sourceMappingURL=if.js.map