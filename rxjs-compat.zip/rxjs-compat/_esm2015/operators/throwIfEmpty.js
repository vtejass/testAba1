export { throwIfEmpty } from 'rxjs/operators';
//# sourceMappingURL=throwIfEmpty.js.map