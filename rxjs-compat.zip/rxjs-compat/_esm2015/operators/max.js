export { max } from 'rxjs/operators';
//# sourceMappingURL=max.js.map