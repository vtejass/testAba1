export { switchMapTo } from 'rxjs/operators';
//# sourceMappingURL=switchMapTo.js.map