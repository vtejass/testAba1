export { materialize } from 'rxjs/operators';
//# sourceMappingURL=materialize.js.map