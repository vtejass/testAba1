export { bufferTime } from 'rxjs/operators';
//# sourceMappingURL=bufferTime.js.map