export { windowTime } from 'rxjs/operators';
//# sourceMappingURL=windowTime.js.map