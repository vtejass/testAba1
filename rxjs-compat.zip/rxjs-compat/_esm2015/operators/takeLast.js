export { takeLast } from 'rxjs/operators';
//# sourceMappingURL=takeLast.js.map