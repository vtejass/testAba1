export { startWith } from 'rxjs/operators';
//# sourceMappingURL=startWith.js.map