export { switchMap } from 'rxjs/operators';
//# sourceMappingURL=switchMap.js.map