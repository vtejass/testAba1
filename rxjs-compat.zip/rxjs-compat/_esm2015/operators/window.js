export { window } from 'rxjs/operators';
//# sourceMappingURL=window.js.map