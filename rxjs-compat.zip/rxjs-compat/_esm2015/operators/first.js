export { first } from 'rxjs/operators';
//# sourceMappingURL=first.js.map