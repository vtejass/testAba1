export { bufferCount } from 'rxjs/operators';
//# sourceMappingURL=bufferCount.js.map