export { single } from 'rxjs/operators';
//# sourceMappingURL=single.js.map