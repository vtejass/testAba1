export { buffer } from 'rxjs/operators';
//# sourceMappingURL=buffer.js.map