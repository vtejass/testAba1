export { timestamp } from 'rxjs/operators';
//# sourceMappingURL=timestamp.js.map