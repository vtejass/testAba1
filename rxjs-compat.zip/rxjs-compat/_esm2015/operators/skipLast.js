export { skipLast } from 'rxjs/operators';
//# sourceMappingURL=skipLast.js.map