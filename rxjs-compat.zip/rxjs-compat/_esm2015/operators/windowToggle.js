export { windowToggle } from 'rxjs/operators';
//# sourceMappingURL=windowToggle.js.map