export { isEmpty } from 'rxjs/operators';
//# sourceMappingURL=isEmpty.js.map