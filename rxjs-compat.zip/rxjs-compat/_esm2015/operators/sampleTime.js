export { sampleTime } from 'rxjs/operators';
//# sourceMappingURL=sampleTime.js.map