export { bufferWhen } from 'rxjs/operators';
//# sourceMappingURL=bufferWhen.js.map