export { groupBy } from 'rxjs/operators';
export { GroupedObservable } from 'rxjs/internal-compatibility';
//# sourceMappingURL=groupBy.js.map