export { mapTo } from 'rxjs/operators';
//# sourceMappingURL=mapTo.js.map