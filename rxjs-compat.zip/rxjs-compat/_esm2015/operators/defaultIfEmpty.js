export { defaultIfEmpty } from 'rxjs/operators';
//# sourceMappingURL=defaultIfEmpty.js.map