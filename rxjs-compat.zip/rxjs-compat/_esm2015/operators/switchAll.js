export { switchAll } from 'rxjs/operators';
//# sourceMappingURL=switchAll.js.map