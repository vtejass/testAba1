export { bufferToggle } from 'rxjs/operators';
//# sourceMappingURL=bufferToggle.js.map