export { windowCount } from 'rxjs/operators';
//# sourceMappingURL=windowCount.js.map