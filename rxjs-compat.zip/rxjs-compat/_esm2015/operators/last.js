export { last } from 'rxjs/operators';
//# sourceMappingURL=last.js.map