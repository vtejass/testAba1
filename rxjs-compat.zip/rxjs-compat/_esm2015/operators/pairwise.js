export { pairwise } from 'rxjs/operators';
//# sourceMappingURL=pairwise.js.map