export { partition } from 'rxjs/operators';
//# sourceMappingURL=partition.js.map