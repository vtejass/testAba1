export { tap } from 'rxjs/operators';
//# sourceMappingURL=tap.js.map