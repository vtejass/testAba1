export { timeInterval } from 'rxjs/operators';
//# sourceMappingURL=timeInterval.js.map