export { elementAt } from 'rxjs/operators';
//# sourceMappingURL=elementAt.js.map