export { windowWhen } from 'rxjs/operators';
//# sourceMappingURL=windowWhen.js.map