export { expand } from 'rxjs/operators';
//# sourceMappingURL=expand.js.map