export { asapScheduler as asap } from 'rxjs';
//# sourceMappingURL=asap.js.map