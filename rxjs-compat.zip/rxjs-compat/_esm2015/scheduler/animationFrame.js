export { animationFrameScheduler as animationFrame } from 'rxjs';
//# sourceMappingURL=animationFrame.js.map