export { queueScheduler as queue } from 'rxjs';
//# sourceMappingURL=queue.js.map