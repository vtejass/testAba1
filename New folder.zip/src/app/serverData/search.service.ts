import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { sampleTest } from './sampleTest.component'

@Injectable()
export class searchService  {
   constructor(private http: Http,private queryName:string,private queryVal:string) {
   }
   searchUsers(queryName:string,queryVal:string):Observable<sampleTest[]>{
    let searchUrl = "http://10.84.44.100:9080/abaService/customers/customerList?"+queryName+"='"+queryVal+"'";
 return this.http.get("http://10.84.44.100:9080/abaService/customers/customerList?")
    .map((res: Response) => res.json().customerList)
    .catch((error: any) => Observable.throw(error.json().error || 'Server error'));
}
}
 