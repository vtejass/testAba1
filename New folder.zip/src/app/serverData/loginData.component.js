"use strict";
var loginData = (function () {
    function loginData(accessToken, statusCode, statusDescription) {
        this.accessToken = accessToken;
        this.statusCode = statusCode;
        this.statusDescription = statusDescription;
    }
    return loginData;
}());
exports.loginData = loginData;
//# sourceMappingURL=loginData.component.js.map