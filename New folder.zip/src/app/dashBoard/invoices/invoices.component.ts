import { Component } from '@angular/core';

@Component({
    selector:'invoices',
    template:'<h2>Invoices Page</h2>'
})

export class InvoicesComponent{}