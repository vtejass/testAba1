import { NgModule } from '@angular/core';
import { Component } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { RouterModule, Routes } from '@angular/router';
import { Router } from "@angular/router";
import {sampleTestService} from '../serverData/sampleTest.service';
import {dashboardbody} from './dashBoardBody/dashboardbody.component';
//import { AppRoutes,AppComponents,DashRouteComponent} from './app.routing';

@Component({
  selector: 'dashboard',
  templateUrl: './dashboard.html',
  styleUrls:['./dashboard.style.css']
})

export class DashBoardComponent{
  //users;
  /* constructor(private userService: sampleTestService) {
      this.users = userService.getUsers();  
      console.log("heree"+this.users);
   }*/
}