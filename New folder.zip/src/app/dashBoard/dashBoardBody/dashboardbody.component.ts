import {Component} from '@angular/core';

@Component({
    selector:'dashBody',
    template:"<h2>DashBoard my</h2>"
})
export class dashboardbody{}