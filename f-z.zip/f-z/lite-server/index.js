'use strict';
module.exports = {
  server: require('./lib/lite-server.js'),
  defaults: require('./lib/config-defaults')
};
