import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Router } from "@angular/router";
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutes,AppComponents} from './app.routing';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports:[BrowserModule,RouterModule,RouterModule.forRoot(AppRoutes),FormsModule,ReactiveFormsModule],
  declarations:[AppComponent,AppComponents],
  providers:[],
  bootstrap:[AppComponent]
})
export class AppModule { }
