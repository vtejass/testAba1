import { DashBoardComponent }  from './dashboard/dashboard.component';
import { LoginComponent }  from './login/login.component';

export const AppComponents: any = [
    DashBoardComponent,
    LoginComponent
];
export const AppRoutes: any = [
    {path :'',component:LoginComponent},
    { path: "dashboard", component: DashBoardComponent}
];