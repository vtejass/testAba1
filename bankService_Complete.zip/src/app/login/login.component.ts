import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder  } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { Router } from "@angular/router";

 @Component({
    selector: 'login',
    templateUrl: './login.html',
    styleUrls:['./login.style.css']
 })

 export class LoginComponent{
    //flags and variables
  statusData:any;
  usernameerror:boolean = false;
  noaccess:boolean = false;
  invalidStatusText:string ="";
  invalidAccessText:string ="";
    //form controls
 username = new FormControl('', [
    Validators.required,
    Validators.minLength(7),
    Validators.maxLength(7)
  ]);
  password = new FormControl('', [
    Validators.required
  ]);
   //form values
   
    loginForm: FormGroup = this.builder.group({
      username: this.username,
      password: this.password
    });

    constructor(private builder: FormBuilder,private router: Router){}
    
    login(){
        this.router.navigate(["dashboard"]);
    }
 }