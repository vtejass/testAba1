import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder  } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { Router } from "@angular/router";
import { loginService } from "../serverData/login.service";
import { loginData } from "../serverData/loginData.component";
 @Component({
    selector: 'login',
    templateUrl: './login.html',
    styleUrls:['./login.style.css']
 })

 export class LoginComponent{
    //flags and variables
  statusData:any;
  statusMessage:string="";
  statusError:boolean = false;
    //form controls
 username = new FormControl('', [
    Validators.required,
    Validators.minLength(7),
    Validators.maxLength(7)
  ]);
  password = new FormControl('', [
    Validators.required
  ]);
   //form values
   
    loginForm: FormGroup = this.builder.group({
      username: this.username,
      password: this.password
    });
    constructor(private builder: FormBuilder,private router: Router,private userLoginService:loginService){}
    
    login() {
    /* this.router.navigate(["dashboard"]);
      this.userLoginService.login(this.loginForm.value.username,this.loginForm.value.password).subscribe(data =>{
      this.statusData = data;
      console.log(this.statusData.username);
      },(error)=>{
        this.statusMessage = 'Error Ouccured';
        alert("here")
      });*/
    if(this.loginForm.valid){
        this.userLoginService.login(this.loginForm.value.username,this.loginForm.value.password).subscribe(data =>{
          this.statusData = data;
              sessionStorage.setItem("accessToken",this.statusData.accesToken);
              sessionStorage.setItem("username",this.loginForm.value.username);
              this.router.navigate(["dashboard"]);
        },(error)=>{
          this.statusMessage=error.headers.get('status-description');
          this.statusError = true;
        });
      }
    }
 }