import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { loginData } from './loginData.component';
@Injectable()
export class loginService{
    constructor(private http:Http){}
    login(username:string,userpwd:string){
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let loginData = {
            "username":username,
            "password":userpwd
        };
        //loginData = loginData.toJSON();
    let options = new RequestOptions({ headers: headers });// http://10.85.47.90:9092/abaService/rest/login  https://jsonplaceholder.typicode.com/posts  http://10.85.82.75:9080/abaService/rest/login
     return this.http.post("https://devinternal.aetna.com/abaService2/rest/login",loginData,options)
     .map((res: Response) => res.json())
     .catch(this.handleError);
    }
    handleError(error: Response){
        console.error(error);
        return Observable.throw(error);
    }
}
//https://devinternal.aetna.com/abaService2/rest/login