import { Pipe, PipeTransform } from '@angular/core';
import { forEach } from '@angular/router/src/utils/collection';

@Pipe({
    name: 'searchFilter',
    pure: false
})

export class SearchCustomerFilter implements PipeTransform {
    transform(items: any[], filter: Object): any {
        if (!items || !filter) {
            return items;
        }
        // filter items array, items which match and return true will be
        // kept, false will be filtered out
        let index:any = Object.keys(filter);
        let filterObject :any;
        console.log(items+"  items");
        var j=0;
       for(var i=0;i<items.length;i++){
            if(items[i][index]==filter[index]){
                console.log("in nnnn "+items[i]);
                filterObject=items[i]
                console.log(filterObject)
                //j++;
            }
       }
       return filterObject.customerList;
        //console.log(filterObject+" objee")
       // return filterObject;
       //console.log(filter[index]+" filter vale"+items.indexOf(filter[index]))
        /*console.log(items.length+" item list "+" filter index "+filter[index]+Object.keys(filter)+" sssss "+ items[1][(filter[index])])
       return items.filter(items => items.indexOf(filter[index]) !== -1);*/
    }
}