import { Component } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import {Injectable} from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Router } from "@angular/router";

import {customerDetailsService} from '../../serverData/customerDetails.service';
@Component({
    selector:'customer',
    templateUrl:'./customers.html',
    styleUrls:['./customers.css']
})

export class CustomerComponent{
    customernameModel:string;
    psuidModel:string;
    controlnumberModel:string;
    statusModel:string;
    searchValue:any = '';
    queryName:string = '';
    queryVal:string = '';
    users:any;
    constructor(private userService: customerDetailsService) {
        this.users = userService.getUsers();
        //users = this.users;
        console.log(this.users)
     }
     
}