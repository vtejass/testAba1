"use strict";
var dashboard_component_1 = require("./dashboard/dashboard.component");
var login_component_1 = require("./login/login.component");
var dashboardbody_component_1 = require("./dashboard/dashboardbody/dashboardbody.component");
var customer_component_1 = require("./dashboard/customers/customer.component");
var invoices_component_1 = require("./dashboard/invoices/invoices.component");
exports.DashRouteComponent = [
    customer_component_1.CustomerComponent,
    invoices_component_1.InvoicesComponent,
    dashboardbody_component_1.dashboardbody
];
exports.AppRoutes = [
    { path: '', component: login_component_1.LoginComponent },
    { path: "dashboard", component: dashboard_component_1.DashBoardComponent, children: [
            { path: 'customers', component: customer_component_1.CustomerComponent, outlet: 'dashboardRoute' },
            { path: "invoices", component: invoices_component_1.InvoicesComponent, outlet: 'dashboardRoute' },
            { path: '', component: dashboardbody_component_1.dashboardbody, outlet: 'dashboardRoute' }
        ] }
];
exports.AppComponents = [
    dashboard_component_1.DashBoardComponent,
    login_component_1.LoginComponent
];
//# sourceMappingURL=app.routing.js.map