import {CustomerComponent} from './customers/customer.component';
import {InvoicesComponent} from './invoices/invoices.component';

export const DashRoutes:any=[
    {path :'/customers',component:CustomerComponent},
    { path: "/invoices", component: InvoicesComponent }
];

export const DashRouteComponent:any = [
    CustomerComponent,
    InvoicesComponent
]