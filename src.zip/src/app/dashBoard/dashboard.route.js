"use strict";
var customer_component_1 = require("./customers/customer.component");
var invoices_component_1 = require("./invoices/invoices.component");
exports.DashRoutes = [
    { path: '/customers', component: customer_component_1.CustomerComponent },
    { path: "/invoices", component: invoices_component_1.InvoicesComponent }
];
exports.DashRouteComponent = [
    customer_component_1.CustomerComponent,
    invoices_component_1.InvoicesComponent
];
//# sourceMappingURL=dashboard.route.js.map