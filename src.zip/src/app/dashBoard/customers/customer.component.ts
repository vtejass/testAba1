import { Component } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import {Injectable} from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Router } from "@angular/router";

import {sampleTestService} from '../../serverData/sampleTest.service';
@Component({
    selector:'customer',
    templateUrl:'./customers.html',
    styleUrls:['./customers.css']
})

export class CustomerComponent{
    customernameModel:string;
    psuidModel:string;
    controlnumberModel:string;
    statusModel:string;
    searchValue:any = '';
    queryName:string = '';
    queryVal:string = '';
    users:any;
    constructor(private userService: sampleTestService) {
        this.users = userService.getUsers();
        //users = this.users;
        console.log(this.users)
     }
     
}