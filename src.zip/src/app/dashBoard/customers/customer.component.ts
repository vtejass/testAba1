import { Component } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import {Injectable} from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Router } from "@angular/router";

import {sampleTestService} from '../../serverData/sampleTest.service';
@Component({
    selector:'customer',
    templateUrl:'./customers.html',
    styleUrls:['./customers.css']
})

export class CustomerComponent{
    customernameModel:string;
    psuidModel:string;
    controlnumberModel:string;
    statusModel:string;
    searchValue:any = '';
    queryName:string = '';
    queryVal:string = '';
    users:any;
    constructor(private userService: sampleTestService) {
        this.users = userService.getUsers();
        //users = this.users;
     }
     /*searchButton(){
        this.queryVal=this.customernameModel;
         this.queryName="customerName";
         this.searchValue={"customerName":this.queryVal};

         let index:any = Object.keys(this.searchValue);
        let filterObject :any;
      //  console.log(items+"  items");
        var j=0;
       for(var details in this.users){
           console.log(details)
           /* if(this.users[i][index]==this.searchValue[index]){
                console.log("in nnnn "+this.users[i]);
                filterObject=this.users[i]
                console.log(filterObject+"ddddddddddsss")
                //j++;
            }
       }
       console.log(this.users +" ddd "+filterObject);
       this.users = filterObject;
     }*/
}