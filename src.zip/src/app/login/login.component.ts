import { Component, OnInit } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import {Injectable} from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Router } from "@angular/router";
import { FormControl, FormGroup, Validators, FormBuilder  } from '@angular/forms';

import {loginData} from '../serverData/loginData.component';
import {loginService} from '../serverData/login.service';


@Component({
  selector: 'login',
  templateUrl: './login.html',
styleUrls:['./login.style.css']
})
export class LoginComponent{
  //flags and variables
  statusData:any;
  usernameerror:boolean = false;
  noaccess:boolean = false;
  invalidStatusText:string ="";
  invalidAccessText:string ="";
//form controls

 username = new FormControl('', [
  Validators.required,
  Validators.minLength(7),
  Validators.maxLength(7)
]);
password = new FormControl('', [
  Validators.required
]);
 //form values
 
  loginForm: FormGroup = this.builder.group({
    username: this.username,
    password: this.password
  });
  //client side validation
  
 constructor(private router: Router,private userloginService:loginService,private builder: FormBuilder) { 

 }

 login() {
  
  // Attempt Logging in...
  if(this.loginForm.valid){
    this.userloginService.login(this.loginForm.value.username,this.loginForm.value.password).subscribe(data => {
      this.statusData = data;
      console.log(this.statusData.statusCode)
       switch(this.statusData.statusCode){
        case '200': {
          sessionStorage.setItem("accessToken",this.statusData.accesToken);
          sessionStorage.setItem("username",this.loginForm.value.username);
          this.router.navigate(["dashboard"]);
        }
        break;
        case '401' : {
          console.log("in here")
          if(this.statusData.statusDescription == "Invalid User ID & Password"){
            this.usernameerror = true;
            this.invalidStatusText = this.statusData.statusDescription;
          } else if(this.statusData.statusDescription == "User doesn't have access"){
            this.noaccess = true;
            this.invalidAccessText = this.statusData.statusDescription;
          }
        }
        break;
      }
    });
  }
}
}

