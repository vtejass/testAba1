import { Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Router } from "@angular/router";

@Component({
  selector: 'login',
  templateUrl: './login.html',
styleUrls:['./login.style.css']
})
export class LoginComponent{
 constructor(private router: Router) { }
  navigate(){
    this.router.navigate(["dashboard"]);
  }
}

