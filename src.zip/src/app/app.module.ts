import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { Router } from "@angular/router";
import { HttpModule } from '@angular/http';
import { AppComponent }  from './app.component';
import { LoginComponent }  from './login/login.component';
import { AppRoutes,AppComponents,DashRouteComponent} from './app.routing';
import {sampleTestService} from './serverData/sampleTest.service';
import {searchService} from './serverData/search.service';
import { FormsModule } from '@angular/forms';
import {SearchCustomerFilter} from './sharedService/searchcustomer.service';

@NgModule({
  imports:      [ BrowserModule,HttpModule,RouterModule,RouterModule.forRoot(AppRoutes),FormsModule],
  declarations: [ AppComponent,AppComponents,DashRouteComponent,SearchCustomerFilter ],
  providers:    [sampleTestService,searchService],
  bootstrap:    [ AppComponent ]
})

export class AppModule { }
