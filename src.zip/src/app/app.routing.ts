import { DashBoardComponent }  from './dashboard/dashboard.component';
import { LoginComponent }  from './login/login.component';
import {dashboardbody} from './dashboard/dashboardbody/dashboardbody.component';
import {CustomerComponent} from './dashboard/customers/customer.component';
import {InvoicesComponent} from './dashboard/invoices/invoices.component';

export const DashRouteComponent:any = [
    CustomerComponent,
    InvoicesComponent,
    dashboardbody
]

export const AppRoutes: any = [
    {path :'',component:LoginComponent},
    { path: "dashboard", component: DashBoardComponent,children:[
       { path :'customers',component:CustomerComponent,outlet:'dashboardRoute'},
       {path: "invoices", component: InvoicesComponent,outlet:'dashboardRoute'},
       { path :'',  component: dashboardbody,outlet:'dashboardRoute'}
    ] }
];
export const AppComponents: any = [
    DashBoardComponent,
    LoginComponent
];