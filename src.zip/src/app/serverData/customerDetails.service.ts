import { Injectable } from '@angular/core';
import { Http, Response, Headers,RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import 'rxjs/add/operator/map';

import { customerData } from './customerData.component';
@Injectable()
export class customerDetailsService {
   constructor(private http: Http) {
   }
 
   getUsers(): Observable<customerData[]> {
       let reqheaders:Headers = new Headers();
       reqheaders.append("Accept","application/json");
       reqheaders.append("AccessToken",sessionStorage.getItem("accessToken"));
       reqheaders.append("UserName",sessionStorage.getItem("username"));
       let options = new RequestOptions({headers: reqheaders});
      return this.http.get("https://devinternal.aetna.com/abaService2/rest/customers",options)
         .map((res: Response) => res.json().customerList);
         //.map((res: Response) => res.json());
   }
}
//https://jsonplaceholder.typicode.com/posts  http://10.85.82.75:9080/abaService/rest/customers