export class customerData{
    constructor(
      public customerName: string,
      public psuid: number,
      public controlNumber: number,
      public status: string
     /* public userid:number,
      public id:string,
      public title:string,
      public body:string*/
    ){}
}