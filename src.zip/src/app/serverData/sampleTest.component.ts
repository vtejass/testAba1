export class sampleTest{
    constructor(
      public customerName: string,
      public psuid: number,
      public controlNumber: number,
      public status: string
    ){}
}