"use strict";
var loginData = (function () {
    function loginData(accesToken, statusCode, statusDescription) {
        this.accesToken = accesToken;
        this.statusCode = statusCode;
        this.statusDescription = statusDescription;
    }
    return loginData;
}());
exports.loginData = loginData;
//# sourceMappingURL=loginData.component.js.map