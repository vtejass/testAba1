import { Injectable } from '@angular/core';
import { Http, Response, Headers,RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { sampleTest } from './sampleTest.component'
//import { RequestOptions } from '@angular/http/src/base_request_options';


@Injectable()
export class sampleTestService {
   constructor(private http: Http) {
   }
 
   getUsers(): Observable<sampleTest[]> {
       let reqheaders:Headers = new Headers();
       reqheaders.append("Accept","application/json");
       reqheaders.append("AccessToken",sessionStorage.getItem("accessToken"));
       reqheaders.append("UserName",sessionStorage.getItem("username"));
       let options = new RequestOptions({headers: reqheaders});
      return this.http.get("http://10.85.82.75:9080/abaService/rest/customers",options)
         .map((res: Response) => res.json().customerList)
         .catch((error: any) => Observable.throw(error.json().error || 'Server error'));
   }
  /* searchUsers(queryName:string,queryVal:string):Observable<sampleTest[]>{
http://10.85.82.75:9080/abaService/rest/login
      let searchUrl = "http://10.84.44.100:9080/abaService/customers/customerList?"+queryName+"='"+queryVal+"'";
      alert(searchUrl)
   return this.http.get("http://10.84.44.100:9080/abaService/customers/customerList?")
      .map((res: Response) => res.json().customerList)
      .catch((error: any) => Observable.throw(error.json().error || 'Server error'));

      http://10.84.44.100:9080/abaService/customers
  }*/
}