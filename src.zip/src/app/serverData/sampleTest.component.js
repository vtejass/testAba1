"use strict";
var sampleTest = (function () {
    function sampleTest(customerName, psuid, controlNumber, status) {
        this.customerName = customerName;
        this.psuid = psuid;
        this.controlNumber = controlNumber;
        this.status = status;
    }
    return sampleTest;
}());
exports.sampleTest = sampleTest;
//# sourceMappingURL=sampleTest.component.js.map