export class loginData{
    constructor(
        public accesToken:string,
        public statusCode:string,
        public statusDescription:string
    ){}
}