import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';

import { loginData } from './loginData.component'

@Injectable()
export class loginService{
    constructor(private http:Http){}
    login(username:string,userpwd:string):Observable<loginData[]>{
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let loginData = {
            "username":username,
            "password":userpwd
        };
        //loginData = loginData.toJSON();
    let options = new RequestOptions({ headers: headers });// http://10.85.47.90:9092/abaService/login
     return this.http.post("http://10.85.82.75:9080/abaService/rest/login",loginData,options)
      .map((res: Response) => res.json())
      .catch((error: any) => Observable.throw(error.json().error || 'Server error'));
    }
}
