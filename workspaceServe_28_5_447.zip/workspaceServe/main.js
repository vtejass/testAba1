(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error('Cannot find module "' + req + '".');
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'app';
    }
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: "<div class='mainDiv'><router-outlet></router-outlet></div>",
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _app_routing__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app.routing */ "./src/app/app.routing.ts");
/* harmony import */ var _serverData_login_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./serverData/login.service */ "./src/app/serverData/login.service.ts");
/* harmony import */ var _serverData_customerDetails_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./serverData/customerDetails.service */ "./src/app/serverData/customerDetails.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};










var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(_app_routing__WEBPACK_IMPORTED_MODULE_6__["AppRoutes"]), _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ReactiveFormsModule"], _angular_http__WEBPACK_IMPORTED_MODULE_3__["HttpModule"]],
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"], _app_routing__WEBPACK_IMPORTED_MODULE_6__["AppComponents"]],
            providers: [_serverData_login_service__WEBPACK_IMPORTED_MODULE_7__["loginService"], _serverData_customerDetails_service__WEBPACK_IMPORTED_MODULE_8__["customerDetailsService"]],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/app.routing.ts":
/*!********************************!*\
  !*** ./src/app/app.routing.ts ***!
  \********************************/
/*! exports provided: AppComponents, AppRoutes */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponents", function() { return AppComponents; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutes", function() { return AppRoutes; });
/* harmony import */ var _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard/dashboard.component */ "./src/app/dashboard/dashboard.component.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _dashboard_customers_customer_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dashboard/customers/customer.component */ "./src/app/dashboard/customers/customer.component.ts");
/* harmony import */ var _dashboard_dashboardbody_dashboardbody_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./dashboard/dashboardbody/dashboardbody.component */ "./src/app/dashboard/dashboardbody/dashboardbody.component.ts");




var AppComponents = [
    _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_0__["DashBoardComponent"],
    _login_login_component__WEBPACK_IMPORTED_MODULE_1__["LoginComponent"],
    _dashboard_customers_customer_component__WEBPACK_IMPORTED_MODULE_2__["CustomerComponent"],
    _dashboard_dashboardbody_dashboardbody_component__WEBPACK_IMPORTED_MODULE_3__["dashboardbody"]
];
var AppRoutes = [
    { path: '', component: _login_login_component__WEBPACK_IMPORTED_MODULE_1__["LoginComponent"] },
    { path: "dashboard", component: _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_0__["DashBoardComponent"], children: [
            { path: 'customers', component: _dashboard_customers_customer_component__WEBPACK_IMPORTED_MODULE_2__["CustomerComponent"], outlet: 'dashboardRoute' },
            { path: '', component: _dashboard_dashboardbody_dashboardbody_component__WEBPACK_IMPORTED_MODULE_3__["dashboardbody"], outlet: 'dashboardRoute' }
        ] }
];


/***/ }),

/***/ "./src/app/dashboard/customers/customer.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/dashboard/customers/customer.component.ts ***!
  \***********************************************************/
/*! exports provided: CustomerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerComponent", function() { return CustomerComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _serverData_customerDetails_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../serverData/customerDetails.service */ "./src/app/serverData/customerDetails.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var CustomerComponent = /** @class */ (function () {
    function CustomerComponent(userService) {
        this.userService = userService;
        this.searchValue = '';
        this.queryName = '';
        this.queryVal = '';
        this.users = userService.getUsers();
        //users = this.users;
        console.log(this.users);
    }
    CustomerComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'customer',
            template: __webpack_require__(/*! ./customers.html */ "./src/app/dashboard/customers/customers.html"),
            styles: [__webpack_require__(/*! ./customers.css */ "./src/app/dashboard/customers/customers.css")]
        }),
        __metadata("design:paramtypes", [_serverData_customerDetails_service__WEBPACK_IMPORTED_MODULE_1__["customerDetailsService"]])
    ], CustomerComponent);
    return CustomerComponent;
}());



/***/ }),

/***/ "./src/app/dashboard/customers/customers.css":
/*!***************************************************!*\
  !*** ./src/app/dashboard/customers/customers.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "h2{\r\n    color: #369;\r\n    font-family: Arial, Helvetica, sans-serif;\r\n    font-size:24px;\r\n  }\r\n  div{\r\n      margin:0;\r\n  }\r\n  .customerContainer{\r\n      width:70%;\r\n      margin:0 auto;\r\n  }\r\n  table{\r\n    margin:0 auto;\r\n    border-spacing:0px 4px;\r\n    border-collapse:separate;\r\n   width:100%;\r\n  }\r\n  table tr{\r\n    border:none;\r\n  }\r\n  table th{\r\n      background:black;\r\n      color:white;\r\n  }\r\n  table th,table td{\r\n    text-align:left;\r\n    border-top:1px solid black;\r\n    border-bottom:1px solid black;\r\n    padding:5px 10px;\r\n  }\r\n  table tr th:first-child{\r\n    border-top-left-radius:8px;\r\n    border-bottom-left-radius:8px;\r\n    border-left:1px solid black !important;\r\n  }\r\n  table tr th:last-child{\r\n    border-top-right-radius:8px;\r\n    border-bottom-right-radius:8px;\r\n    border-right:1px solid black !important;\r\n  }\r\n  table tr td:first-child{\r\n    border-top-left-radius:8px;\r\n    border-bottom-left-radius:8px;\r\n    border-left:1px solid black;\r\n  }\r\n  table tr td:last-child{\r\n    border-top-right-radius:8px;\r\n    border-bottom-right-radius:8px;\r\n    border-right:1px solid black;\r\n  }"

/***/ }),

/***/ "./src/app/dashboard/customers/customers.html":
/*!****************************************************!*\
  !*** ./src/app/dashboard/customers/customers.html ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"customerContainer\">\r\n<div class=\"searchCustomer\">\r\n    <input type=\"text\" placeholder=\"Customer Name\" name=\"customername\" #customername [(ngModel)]=\"customernameModel\">\r\n    <input type=\"text\" placeholder=\"PSUID\" name=\"psuid\" #psuid [(ngModel)]=\"psuidModel\">\r\n    <input type=\"text\" placeholder=\"Control Number\" name=\"controlnumber\" #controlnumber [(ngModel)]=\"controlnumberModel\">\r\n    <input type=\"text\" placeholder=\"Status\" name=\"status\" #status [(ngModel)]=\"statusModel\">\r\n    <button  (click)=\"searchButton()\" >Search</button>\r\n</div>    \r\n<table>\r\n    <thead>\r\n        <tr>\r\n            <th>Customer Name</th>\r\n            <th>PSUID</th>\r\n            <th>Control Number</th>\r\n            <th>Status</th>\r\n            <tr>\r\n        </thead>\r\n    <!--<tr *ngFor = \"let user of users | async\">\r\n        <td>{{user.customerName}}</td>\r\n        <td>{{user.psuid}}</td>\r\n         <td>{{user.controlNumber}}</td>\r\n         <td>{{user.status}}</td>\r\n        </tr>    -->\r\n        <tr *ngFor = \"let user of users | async\">\r\n        <td>{{user.userid}}</td>\r\n        <td>{{user.id}}</td>\r\n         <td>{{user.title}}</td>\r\n         <td>{{user.body}}</td>\r\n        </tr>\r\n</table>\r\n</div>"

/***/ }),

/***/ "./src/app/dashboard/dashboard.component.ts":
/*!**************************************************!*\
  !*** ./src/app/dashboard/dashboard.component.ts ***!
  \**************************************************/
/*! exports provided: DashBoardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashBoardComponent", function() { return DashBoardComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var DashBoardComponent = /** @class */ (function () {
    function DashBoardComponent() {
    }
    DashBoardComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'dashboard',
            template: __webpack_require__(/*! ./dashboard.html */ "./src/app/dashboard/dashboard.html"),
            styles: [__webpack_require__(/*! ./dashboard.style.css */ "./src/app/dashboard/dashboard.style.css")]
        })
    ], DashBoardComponent);
    return DashBoardComponent;
}());



/***/ }),

/***/ "./src/app/dashboard/dashboard.html":
/*!******************************************!*\
  !*** ./src/app/dashboard/dashboard.html ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<nav>\r\n        <ul>\r\n            <li><a [routerLink]=\"['/dashboard']\">Home</a></li>\r\n            <li><a [routerLink]=\"['/dashboard', {outlets: {'dashboardRoute': ['customers']}}]\" skipLocationChange>Customers</a></li>\r\n            <li><a [routerLink]=\"['/dashboard', {outlets: {'dashboardRoute': ['invoices']}}]\" skipLocationChange>Invoices</a></li>\r\n            <li><a [routerLink]=\"['/auditLogs', {outlets: {'dashboardRoute': ['auditLogs']}}]\">Audit Logs</a></li>\r\n            <li><a [routerLink]=\"['/reports', {outlets: {'dashboardRoute': ['reports']}}]\">Reports</a></li>\r\n            <li><a [routerLink]=\"['/bulkUploads', {outlets: {'dashboardRoute': ['bulkUploads']}}]\">Bulk Uploads</a></li>\r\n        </ul>\r\n    </nav>\r\n    <router-outlet name='dashboardRoute'></router-outlet>\r\n    "

/***/ }),

/***/ "./src/app/dashboard/dashboard.style.css":
/*!***********************************************!*\
  !*** ./src/app/dashboard/dashboard.style.css ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "nav{\r\n    text-align:center;\r\n  }\r\n  ul li{\r\n    display:inline-block;\r\n    margin:10px 10px;\r\n  }"

/***/ }),

/***/ "./src/app/dashboard/dashboardbody/dashboardbody.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/dashboard/dashboardbody/dashboardbody.component.ts ***!
  \********************************************************************/
/*! exports provided: dashboardbody */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "dashboardbody", function() { return dashboardbody; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var dashboardbody = /** @class */ (function () {
    function dashboardbody() {
    }
    dashboardbody = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'dashBody',
            template: "<h2>DashBoard my</h2>"
        })
    ], dashboardbody);
    return dashboardbody;
}());



/***/ }),

/***/ "./src/app/login/login.component.ts":
/*!******************************************!*\
  !*** ./src/app/login/login.component.ts ***!
  \******************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _serverData_login_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../serverData/login.service */ "./src/app/serverData/login.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var LoginComponent = /** @class */ (function () {
    function LoginComponent(builder, router, userLoginService) {
        this.builder = builder;
        this.router = router;
        this.userLoginService = userLoginService;
        this.usernameerror = false;
        this.noaccess = false;
        this.invalidStatusText = "";
        this.invalidAccessText = "";
        //form controls
        this.username = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]('', [
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required,
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].minLength(7),
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].maxLength(7)
        ]);
        this.password = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]('', [
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required
        ]);
        //form values
        this.loginForm = this.builder.group({
            username: this.username,
            password: this.password
        });
    }
    LoginComponent.prototype.login = function () {
        var _this = this;
        this.router.navigate(["dashboard"]);
        this.userLoginService.login(this.loginForm.value.username, this.loginForm.value.password).subscribe(function (data) {
            _this.statusData = data;
            console.log(_this.statusData.username);
            /* if(this.loginForm.valid){
               this.userLoginService.login(this.loginForm.value.username,this.loginForm.value.password).subscribe(data =>{
                 this.statusData = data;
                 switch(this.statusData.statusCode){
                   case '200':{
                     sessionStorage.setItem("accessToken",this.statusData.accesToken);
                     sessionStorage.setItem("username",this.loginForm.value.username);
                     this.router.navigate(["dashboard"]);
                   }
                   break;
                   case '401':{
                     if(this.statusData.statusDescription == "Invalid User ID & Password"){
                         this.usernameerror = true;
                         this.invalidStatusText = this.statusData.statusDescription;
                       } else if(this.statusData.statusDescription == "User doesn't have access"){
                         this.noaccess = true;
                         this.invalidAccessText = this.statusData.statusDescription;
                       }
                     }
                     break;
                   }*/
        });
    };
    LoginComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'login',
            template: __webpack_require__(/*! ./login.html */ "./src/app/login/login.html"),
            styles: [__webpack_require__(/*! ./login.style.css */ "./src/app/login/login.style.css")]
        }),
        __metadata("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _serverData_login_service__WEBPACK_IMPORTED_MODULE_3__["loginService"]])
    ], LoginComponent);
    return LoginComponent;
}());



/***/ }),

/***/ "./src/app/login/login.html":
/*!**********************************!*\
  !*** ./src/app/login/login.html ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"loginSection\">\r\n        <div>\r\n            <div class=\"aetnaLogo\"></div>\r\n                <section>\r\n                    <div class=\"loginLogo\"></div>\r\n                    <h1>Banking Application</h1>\r\n                    <form class=\"loginBody\" [formGroup]=\"loginForm\" (ngSubmit)=\"login()\">\r\n                        <div>\r\n                            <input placeholder=\"UserName\" [ngClass]=\"{'inputError':!username.valid && username.touched}\" name=\"username\" #uname [formControl]=\"username\" type=\"text\">\r\n                            <p class=\"error\" [hidden]=\"username.valid || username.untouched\">\r\n                                    <span [hidden]=\"!username.hasError('minlength')\">\r\n                                            Username must have 7 characters\r\n                                        </span>\r\n                                    <span [hidden]=\"!username.hasError('maxlength')\">\r\n                                            Username must have 7 characters\r\n                                    </span>\r\n                                <span [hidden]=\"!username.hasError('required')\">\r\n                                    Username is required\r\n                                </span>\r\n                            </p>\r\n                        </div>\r\n                        <div>\r\n                            <input type=\"password\" [ngClass]=\"{'inputPwdError':!password.valid && password.touched}\" name=\"userpassword\" #upwrd [formControl]=\"password\" placeholder=\"Password\">\r\n                            <p [hidden]=\"password.valid || password.untouched\">\r\n                                <span class=\"error\" [hidden]=\"!password.hasError('required')\">\r\n                                    Password is required\r\n                                </span>\r\n                            </p>\r\n                        </div>\r\n                        <div>\r\n                            <button [disabled]=\"!loginForm.valid\">LOGIN</button>\r\n                            <p class=\"error\" [hidden]=\"!usernameerror\">\r\n                                    {{invalidStatusText}}\r\n                                </p>\r\n                            <p class=\"error\" [hidden]=\"!noaccess\">\r\n                                    {{invalidAccessText}}\r\n                                </p>\r\n                        </div>\r\n                    </form>\r\n            </section>\r\n            <div class=\"copyright\">\r\n                Copyright &copy; 2001-2018 Aetna Inc.\r\n            </div>\r\n        </div>\r\n    </div>"

/***/ }),

/***/ "./src/app/login/login.style.css":
/*!***************************************!*\
  !*** ./src/app/login/login.style.css ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\nh1 {\r\n    color:#383838;\r\n    font-size: 24px;\r\n    font-weight:normal;\r\n  }\r\n  section{\r\n      width: 429px;\r\n      margin: 25px auto;\r\n      border-radius: 17px;\r\n      padding: 3% 0;\r\n      text-align: center;\r\n      background-color: #fff;\r\n      box-shadow: 1px 1px 27px 0px\r\n  }\r\n  section input,section button{\r\n      border-radius:4px;\r\n      border:1px solid #000;\r\n      height:30px;\r\n      padding-left:4px;\r\n      width:65%;\r\n  }\r\n  .loginBody div{\r\n      margin:7px 10px;\r\n  }\r\n  .loginBody input,.loginBody button{\r\n      width: 69%;\r\n      height: 40px;\r\n      border-radius: 20px;\r\n      padding: 0 15px;\r\n  }\r\n  .loginBody p{\r\n      margin:4px 0 0 0;\r\n  }\r\n  .loginBody input[type=\"text\"],.loginBody input[type=\"password\"]{\r\n      background-repeat: no-repeat;\r\n      background-position: right;\r\n      background-position: 93% 51%;\r\n      background-size: 6%;\r\n      border:1px solid #e1e1e1;\r\n      color:#767474;\r\n      font-size:14px;\r\n  }\r\n  .loginBody button{\r\n      padding:0px;\r\n      width:76%;\r\n      background-color:#d8176e;\r\n      color:#fff;\r\n      border:none;\r\n      letter-spacing: 4px;\r\n      font-size: 14px;\r\n  }\r\n  .loginBody div {\r\n      margin: 2% 0 !important;\r\n      height:65px;\r\n  }\r\n  .copyright{\r\n      margin:0 auto;\r\n      text-align:center;\r\n      color:white;\r\n      font-size:12px;\r\n  }\r\n  .error{\r\n      color:#e42929;\r\n      margin:5px 0;\r\n      font-weight:bold;\r\n      font-size:14px;\r\n  }\r\n  button:disabled{\r\n      opacity:0.5;\r\n  }\r\n  .inputError,.inputPwdError{\r\n      border:2px solid #e42929 !important;\r\n  }"

/***/ }),

/***/ "./src/app/serverData/customerDetails.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/serverData/customerDetails.service.ts ***!
  \*******************************************************/
/*! exports provided: customerDetailsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "customerDetailsService", function() { return customerDetailsService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm5/add/operator/map.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var customerDetailsService = /** @class */ (function () {
    function customerDetailsService(http) {
        this.http = http;
    }
    customerDetailsService.prototype.getUsers = function () {
        var reqheaders = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]();
        reqheaders.append("Accept", "application/json");
        // reqheaders.append("AccessToken",sessionStorage.getItem("accessToken"));
        //reqheaders.append("UserName",sessionStorage.getItem("username"));
        var options = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["RequestOptions"]({ headers: reqheaders });
        return this.http.get("https://jsonplaceholder.typicode.com/posts", options)
            .map(function (res) { return res.json(); });
    };
    customerDetailsService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"]])
    ], customerDetailsService);
    return customerDetailsService;
}());

//https://jsonplaceholder.typicode.com/posts  http://10.85.82.75:9080/abaService/rest/customers


/***/ }),

/***/ "./src/app/serverData/login.service.ts":
/*!*********************************************!*\
  !*** ./src/app/serverData/login.service.ts ***!
  \*********************************************/
/*! exports provided: loginService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "loginService", function() { return loginService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm5/add/operator/map.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var loginService = /** @class */ (function () {
    function loginService(http) {
        this.http = http;
    }
    loginService.prototype.login = function (username, userpwd) {
        var headers = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({ 'Content-Type': 'application/json' });
        var loginData = {
            "username": username,
            "password": userpwd
        };
        //loginData = loginData.toJSON();
        var options = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["RequestOptions"]({ headers: headers }); // http://10.85.47.90:9092/abaService/rest/login  https://jsonplaceholder.typicode.com/posts  http://10.85.82.75:9080/abaService/rest/login
        return this.http.post("https://jsonplaceholder.typicode.com/posts", loginData, options)
            .map(function (res) { return res.json(); });
    };
    loginService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"]])
    ], loginService);
    return loginService;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\540455\Desktop\angularWorkSpace\WorkSpace1\quickstart-master\quickstart-master\workspaceServe\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map