export declare const __core_private_testing_placeholder__ = "";
