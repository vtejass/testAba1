import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { Router } from "@angular/router";
import { HttpModule } from '@angular/http';
import { AppComponent }  from './app.component';
import { LoginComponent }  from './login/login.component';
import { AppRoutes,AppComponents} from './app.routing';
import {sampleTestService} from './serverData/sampleTest.service';

@NgModule({
  imports:      [ BrowserModule,HttpModule,RouterModule,RouterModule.forRoot(AppRoutes)],
  declarations: [ AppComponent,AppComponents ],
  providers:    [sampleTestService],
  bootstrap:    [ AppComponent ]
})

export class AppModule { }
