import { Component } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import {sampleTestService} from 'app/serverData/sampleTest.service';

@Component({
  selector: 'dashboard',
  templateUrl: './dashboard.html',
  styleUrls:['./dashboard.style.css']
})

export class DashBoardComponent{
  //users;
   constructor(private userService: sampleTestService) {
      this.users = userService.getUsers();  
   }
}