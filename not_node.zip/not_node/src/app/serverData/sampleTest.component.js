"use strict";
var sampleTest = (function () {
    function sampleTest(id, name, username, email) {
        this.id = id;
        this.name = name;
        this.username = username;
        this.email = email;
    }
    return sampleTest;
}());
exports.sampleTest = sampleTest;
//# sourceMappingURL=sampleTest.component.js.map