"use strict";
var dashboard_component_1 = require("./dashboard/dashboard.component");
var login_component_1 = require("./login/login.component");
exports.AppRoutes = [
    { path: '', component: login_component_1.LoginComponent },
    { path: "dashboard", component: dashboard_component_1.DashBoardComponent }
];
exports.AppComponents = [
    dashboard_component_1.DashBoardComponent,
    login_component_1.LoginComponent
];
//# sourceMappingURL=app.routing.js.map