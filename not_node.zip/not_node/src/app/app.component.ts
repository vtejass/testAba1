import { Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Router } from "@angular/router";

import { LoginComponent }  from './login/login.component';
@Component({
  selector: 'my-app',
  template: `<div><router-outlet></router-outlet></div>`,
})
export class AppComponent  { 
  
}
