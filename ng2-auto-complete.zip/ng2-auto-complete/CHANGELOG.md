### [0.12.0]
- added a new property `match-formatted`
### [0.11.0]
- added a new property `value-formatter`
### [0.10.10]
- fixed `accept-user-input`, fixed tests
### [0.10.9]
- bug fox on list formatter not applying and dropdown positioning
- fixed (undefined) display when source is list of number or boolean
### [0.10.8]
- fixed (undefined) display when source is list of number or boolean
### [0.10.7]
- introduced `select-valule-of`
- removed `value-property-name`
- list-formatter now accepts sttirng e.g. `(id) value`
### [0.10.6]
- testing with initial focus
### [0.10.5]
- more checking before set value
