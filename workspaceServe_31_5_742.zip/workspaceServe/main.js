(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error('Cannot find module "' + req + '".');
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'app';
    }
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: "<div class='mainDiv'><router-outlet></router-outlet></div>",
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _app_routing__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app.routing */ "./src/app/app.routing.ts");
/* harmony import */ var ngx_bootstrap_dropdown__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-bootstrap/dropdown */ "./node_modules/ngx-bootstrap/dropdown/index.js");
/* harmony import */ var _serverData_login_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./serverData/login.service */ "./src/app/serverData/login.service.ts");
/* harmony import */ var _serverData_customerDetails_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./serverData/customerDetails.service */ "./src/app/serverData/customerDetails.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};











var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(_app_routing__WEBPACK_IMPORTED_MODULE_6__["AppRoutes"]), _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ReactiveFormsModule"], _angular_http__WEBPACK_IMPORTED_MODULE_3__["HttpModule"], ngx_bootstrap_dropdown__WEBPACK_IMPORTED_MODULE_7__["BsDropdownModule"].forRoot()],
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"], _app_routing__WEBPACK_IMPORTED_MODULE_6__["AppComponents"]],
            providers: [_serverData_login_service__WEBPACK_IMPORTED_MODULE_8__["loginService"], _serverData_customerDetails_service__WEBPACK_IMPORTED_MODULE_9__["customerDetailsService"]],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/app.routing.ts":
/*!********************************!*\
  !*** ./src/app/app.routing.ts ***!
  \********************************/
/*! exports provided: AppComponents, AppRoutes */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponents", function() { return AppComponents; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutes", function() { return AppRoutes; });
/* harmony import */ var _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard/dashboard.component */ "./src/app/dashboard/dashboard.component.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _dashboard_customers_customer_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dashboard/customers/customer.component */ "./src/app/dashboard/customers/customer.component.ts");
/* harmony import */ var _dashboard_dashboardBody_dashboardBody_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./dashboard/dashboardBody/dashboardBody.component */ "./src/app/dashboard/dashboardBody/dashboardBody.component.ts");




var AppComponents = [
    _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_0__["DashBoardComponent"],
    _login_login_component__WEBPACK_IMPORTED_MODULE_1__["LoginComponent"],
    _dashboard_customers_customer_component__WEBPACK_IMPORTED_MODULE_2__["CustomerComponent"],
    _dashboard_dashboardBody_dashboardBody_component__WEBPACK_IMPORTED_MODULE_3__["dashboardbody"]
];
var AppRoutes = [
    { path: '', component: _login_login_component__WEBPACK_IMPORTED_MODULE_1__["LoginComponent"] },
    { path: "dashboard", component: _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_0__["DashBoardComponent"], children: [
            { path: 'customers', component: _dashboard_customers_customer_component__WEBPACK_IMPORTED_MODULE_2__["CustomerComponent"], outlet: 'dashboardRoute' },
            { path: '', component: _dashboard_dashboardBody_dashboardBody_component__WEBPACK_IMPORTED_MODULE_3__["dashboardbody"], outlet: 'dashboardRoute' }
        ] }
];


/***/ }),

/***/ "./src/app/dashboard/customers/customer.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/dashboard/customers/customer.component.ts ***!
  \***********************************************************/
/*! exports provided: CustomerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerComponent", function() { return CustomerComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _serverData_customerDetails_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../serverData/customerDetails.service */ "./src/app/serverData/customerDetails.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var CustomerComponent = /** @class */ (function () {
    function CustomerComponent(userService, builder) {
        this.userService = userService;
        this.builder = builder;
        this.searchCustomerName = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]('', []);
        this.searchPsuid = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]('', []);
        this.searchControlnumber = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]('', []);
        this.searchStatus = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]('', []);
        this.searchEffectiveDate = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]('', []);
        this.searchCustomersForm = this.builder.group({
            searchCustomerName: this.searchCustomerName,
            searchPsuid: this.searchPsuid,
            searchControlnumber: this.searchControlnumber,
            searchStatus: this.searchStatus,
            searchEffectiveDate: this.searchEffectiveDate
        });
        this.users = userService.getUsers();
    }
    CustomerComponent.prototype.searchCustomers = function () {
        this.users = this.userService.getUsers();
        console.log(this.users);
    };
    CustomerComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'customer',
            template: __webpack_require__(/*! ./customers.html */ "./src/app/dashboard/customers/customers.html"),
            styles: [__webpack_require__(/*! ./customers.css */ "./src/app/dashboard/customers/customers.css")]
        }),
        __metadata("design:paramtypes", [_serverData_customerDetails_service__WEBPACK_IMPORTED_MODULE_2__["customerDetailsService"], _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"]])
    ], CustomerComponent);
    return CustomerComponent;
}());



/***/ }),

/***/ "./src/app/dashboard/customers/customers.css":
/*!***************************************************!*\
  !*** ./src/app/dashboard/customers/customers.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "  h1{\r\n    color:#7a3090;\r\n    font-size:18px;\r\n    margin:0px;\r\n  }\r\n  .searchCustomer{\r\n    text-align: center;\r\n  }\r\n  .searchCustomer input{\r\n      width: 14%;\r\n      height: 35px;\r\n      border-radius: 20px;\r\n      padding: 0 15px;\r\n      border:1px solid #e1e1e1;\r\n      color:#767474;\r\n      font-size:12px;\r\n      margin:0 1%;\r\n}\r\n  .statusInput{\r\n  width:17%;\r\n}\r\n  .searchCustomer .customerInput{\r\n  width:18%;\r\n}\r\n  .searchCustomer{\r\n  width:17%;\r\n}\r\n  .statusInputContainer{\r\n    width: 17%;\r\n    height: 35px;\r\n    border-radius: 20px;\r\n    /* padding: 0 0 0 15px; */\r\n    border: 1px solid #e1e1e1;\r\n    color: #767474;\r\n    font-size: 12px;\r\n    margin: 0 1%;\r\n}\r\n  .statusInput{\r\n  width:100%;\r\n  height: 100%;\r\n  border:none;\r\n  border-radius: 20px;\r\n  border-right: 21px solid white;\r\n  padding-left: 15px;\r\n}\r\n  .searchCustomer .effDateInput{\r\n  width: 18%;\r\n}\r\n  div{\r\n      margin:0;\r\n  }\r\n  .customerContainer{\r\n    padding:0 5%;\r\n      margin:0 auto;\r\n  }\r\n  table{\r\n    margin:0 auto;\r\n    border-spacing:0px 2px;\r\n    border-collapse:separate;\r\n    width:100%;\r\n  }\r\n  table tr{\r\n    border:none;\r\n  }\r\n  table th{\r\n      background:#3b184c;\r\n      color:white;\r\n      font-weight: normal;\r\n      padding:1% 0;\r\n  }\r\n  table th,table td{\r\n    text-align:left;\r\n    padding:10px 10px;\r\n    font-size: 12px;\r\n  }\r\n  table td{\r\n    background:white;\r\n  }\r\n  table tr th:first-child{\r\n    border-top-left-radius:8px;\r\n    border-bottom-left-radius:8px;\r\n  }\r\n  table tr th:last-child{\r\n    border-top-right-radius:8px;\r\n    border-bottom-right-radius:8px;\r\n  }\r\n  table tr td:first-child{\r\n    border-top-left-radius:8px;\r\n    border-bottom-left-radius:8px;\r\n  }\r\n  table tr td:last-child{\r\n    border-top-right-radius:8px;\r\n    border-bottom-right-radius:8px;\r\n  }\r\n  table tr td:first-child{\r\n    color:#7a3090;\r\n    font-weight: 600;\r\n  }\r\n  .customerContainer{\r\n    padding:3% 0 0 0;\r\n  }\r\n  .searchCustomer{\r\n    padding: 1% 0 2% 0;\r\n    background: white;\r\n    width: 90%;\r\n    margin: 0 auto;\r\n    border-radius:4px;\r\n  }\r\n  .tableContainer{\r\n    width:90%;\r\n    margin:0 auto;\r\n  }\r\n  .searchCustomer h1{\r\n    margin:5px 0 10px 0;\r\n  }\r\n  .searchCustomersForm{\r\n    padding-bottom:1%;\r\n  }\r\n  .addCustomer{\r\n    font-size:12px;\r\n    color:#d41970;\r\n    text-transform: capitalize;\r\n  }\r\n  .tableContainer .row{\r\n  padding:1% 0;\r\n  color:white;\r\n  font-size:12px;\r\n  align-items: center;\r\n}\r\n  .itemCount button{\r\n    border: 1px solid white;\r\n    background: none;\r\n    width: 35px;\r\n    height: 20px;\r\n    padding: 0 !important;\r\n    border-radius: 15px;\r\n    color: white;\r\n    font-size: 12px;\r\n}\r\n  .pageValue{\r\n  display: inline-block;\r\n    width: 55px;\r\n    height: 20px;\r\n    border: 1px solid white;\r\n    text-align: center;\r\n    border-radius: 15px;\r\n    vertical-align: middle;\r\n}\r\n  .paginationtop{\r\n  text-align: right;\r\n  padding:0;\r\n}\r\n  .bottomPage{\r\n  padding:0 !important;\r\n}\r\n  .pending{\r\n  color:#2067ac;\r\n}\r\n  .terminated{\r\n  color:#d12128;\r\n}\r\n  .approved{\r\n  color:#2ab275;\r\n}"

/***/ }),

/***/ "./src/app/dashboard/customers/customers.html":
/*!****************************************************!*\
  !*** ./src/app/dashboard/customers/customers.html ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"customerContainer\">\r\n<div class=\"searchCustomer\">\r\n    <h1>Search Customer</h1>\r\n    <form class=\"searchCustomersForm\" [formGroup]=\"searchCustomersForm\" (ngSubmit)=\"searchCustomers()\"><!-- -->\r\n        <input type=\"text\" class=\"customerInput\" placeholder=\"Customer Name\" name=\"customername\" [formControl]=\"searchCustomerName\">\r\n        <input type=\"text\" class=\"psuidInput\" placeholder=\"PSUID\" name=\"psuid\" [formControl]=\"searchPsuid\">\r\n        <input type=\"text\" class=\"ctrlInput\" placeholder=\"Control Number\" name=\"controlnumber\" #controlnumber [formControl]=\"searchControlnumber\">\r\n        <!--<input type=\"text\" class=\"statusInput\" placeholder=\"Status\" name=\"status\" [formControl]=\"searchStatus\">-->\r\n        <div class=\"statusInputContainer inlineBlock\">\r\n            <select class=\"statusInput\" name=\"statusnumber\">\r\n            <option selected value=\"-\" disabled>Status</option>\r\n            <option value=\"terminated\">Terminated</option>\r\n            <option value=\"pending\">Pending</option>\r\n            <option value=\"approved\">Approved</option>\r\n        </select>\r\n        </div>\r\n       <!-- <div  dropdown class=\"dropdown inlineBlock statusInput\">\r\n            <button dropdownToggle type=\"button\" class=\"dropdownButtonStatus btn dropdown-toggle btn-default\" data-toggle=\"dropdown\"><span>Status</span><span class=\"caret\"></span></button>\r\n            <div>\r\n                <ul class=\"dropdown-menu\" *dropdownMenu>\r\n                        <li><a href=\"\">Pending</a></li>\r\n                        <li><a href=\"\">Approved</a></li>\r\n                        <li><a href=\"\">Terminated</a></li>\r\n                    </ul>\r\n            </div>\r\n        </div>-->\r\n        <input type=\"text\" class=\"effDateInput\" placeholder=\"Effective Date\" name=\"effectiveDate\" [formControl]=\"searchEffectiveDate\">\r\n        <button class=\"searchButton\" name='customerSearch'></button>\r\n    </form>\r\n    <a href=\"\" class=\"addCustomer\"><span class=\"addIcon\"></span><span> ADD CUSTOMER</span></a>\r\n    <!--<div class=\"add\"><span> &#10010;</span></div>-->\r\n</div>\r\n<div class=\"tableContainer\">\r\n    <div class=\"row\">\r\n    <div class=\"sorttop col-md-2\">\r\n        Click Column <span class=\"sort sortDown\"></span> tiles to sort\r\n    </div>\r\n    <div class=\"col-md-5\"></div>\r\n    <div class=\"paginationtop col-md-5\">\r\n        <div class=\"row\">\r\n            <div class=\"col-md-2\"></div>\r\n            <div class=\"col-md-6\">Showing Page <span class=\"pageValue\"><span class=\"leftArrow\"></span>1<span class=\"rightArrow\"></span></span> of <span class=\"totalPages\">110</span></div>\r\n        <div dropdown class=\"dropdown itemCount col-md-4\"><span>View \r\n            <button dropdownToggle type=\"button\" class=\"btn dropdown-toggle btn-default\" data-toggle=\"dropdown\">\r\n                <span>1\r\n                    <span class=\"caret\"></span>\r\n                </span>\r\n            </button>\r\n        </span> Items\r\n        <div>\r\n                <ul class=\"dropdown-menu\" *dropdownMenu>\r\n                        <li>1</li><li>2</li><li>3</li><li>4</li><li>5</li><li>6</li><li>7</li><li>8</li><li>9</li><li>10</li>\r\n                    </ul> \r\n            </div> \r\n        </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n<table class=\"customerSearchTable\">\r\n    <thead>\r\n        <tr>\r\n            <th><span class=\"sortUp\"></span>\r\n    <!-- *ngIf=\"(column == 'id' && !isDesc)\"<span *ngIf=\"(column == 'id' && isDesc)\">&#9660;</span>--> CUSTOMER NAME</th>\r\n            <th>PSUID</th>\r\n            <th>CONTROL NUMBER</th>\r\n            <th><span>&#9650;</span> STATUS</th>\r\n            <th>REASON</th>\r\n            <th><span>&#9650;</span> EFFECTIVE DATE</th>\r\n            <th>ACTION</th>\r\n            <tr>\r\n        </thead>\r\n        <tbody>\r\n            <tr>\r\n                <td>American Internation Group</td>\r\n                <td>123456789012345</td>\r\n                <td>1234567</td>\r\n                <td><span class=\"pending\"><span class=\"statusIcon\"></span><span class=\"statusText\">Pending</span></span></td>\r\n                <td>Clean up data and list in RTC</td>\r\n                <td>02/01/2018</td>\r\n                <td><span class=\"viewIcon\"></span><span class=\"editIcon\"></span></td>\r\n            </tr>\r\n            <tr>\r\n                <td>American Internation Group</td>\r\n                <td>123456789012345</td>\r\n                <td>1234567</td>\r\n                <td><span class=\"approved\"><span class=\"statusIcon\"></span><span class=\"statusText\">Approved</span></span></td>\r\n                <td>Clean up data and list in RTC</td>\r\n                <td>02/01/2018</td>\r\n                <td><span class=\"viewIcon\"></span><span class=\"editIcon\"></span></td>\r\n            </tr>\r\n            <tr>\r\n                <td>American Internation Group</td>\r\n                <td>123456789012345</td>\r\n                <td>1234567</td>\r\n                <td><span class=\"terminated\"><span class=\"statusIcon\"></span><span class=\"statusText\">Terminated</span></span></td>\r\n                <td>Clean up data and list in RTC</td>\r\n                <td>02/01/2018</td>\r\n                <td><span class=\"viewIcon\"></span><span class=\"editIcon\"></span></td>\r\n            </tr>\r\n            <tr>\r\n                <td>American Internation Group</td>\r\n                <td>123456789012345</td>\r\n                <td>1234567</td>\r\n                <td><span class=\"pending\"><span class=\"statusIcon\"></span><span class=\"statusText\">Pending</span></span></td>\r\n                <td>Clean up data and list in RTC</td>\r\n                <td>02/01/2018</td>\r\n                <td><span class=\"viewIcon\"></span><span class=\"editIcon\"></span></td>\r\n            </tr>\r\n            <tr>\r\n                <td>American Internation Group</td>\r\n                <td>123456789012345</td>\r\n                <td>1234567</td>\r\n                <td><span class=\"pending\"><span class=\"statusIcon\"></span><span class=\"statusText\">Pending</span></span></td>\r\n                <td>Clean up data and list in RTC</td>\r\n                <td>02/01/2018</td>\r\n                <td><span class=\"viewIcon\"></span><span class=\"editIcon\"></span></td>\r\n            </tr>\r\n            <tr>\r\n                <td>American Internation Group</td>\r\n                <td>123456789012345</td>\r\n                <td>1234567</td>\r\n                <td><span class=\"pending\"><span class=\"statusIcon\"></span><span class=\"statusText\">Pending</span></span></td>\r\n                <td>Clean up data and list in RTC</td>\r\n                <td>02/01/2018</td>\r\n                <td><span class=\"viewIcon\"></span><span class=\"editIcon\"></span></td>\r\n            </tr>\r\n            <tr>\r\n                <td>American Internation Group</td>\r\n                <td>123456789012345</td>\r\n                <td>1234567</td>\r\n                <td><span class=\"pending\"><span class=\"statusIcon\"></span><span class=\"statusText\">Pending</span></span></td>\r\n                <td>Clean up data and list in RTC</td>\r\n                <td>02/01/2018</td>\r\n                <td><span class=\"viewIcon\"></span><span class=\"editIcon\"></span></td>\r\n            </tr>\r\n            <tr>\r\n                <td>American Internation Group</td>\r\n                <td>123456789012345</td>\r\n                <td>1234567</td>\r\n                <td><span class=\"pending\"><span class=\"statusIcon\"></span><span class=\"statusText\">Pending</span></span></td>\r\n                <td>Clean up data and list in RTC</td>\r\n                <td>02/01/2018</td>\r\n                <td><span class=\"viewIcon\"></span><span class=\"editIcon\"></span></td>\r\n            </tr>\r\n        </tbody>\r\n   <!-- <tr *ngFor = \"let user of users | async\">\r\n        <td>{{user.customerName}}</td>\r\n        <td>{{user.psuid}}</td>\r\n         <td>{{user.controlNumber}}</td>\r\n         <td>{{user.status}}</td>\r\n        </tr>-->\r\n        <!--<tr *ngFor = \"let user of users | async\">\r\n        <td>{{user.userid}}</td>\r\n        <td>{{user.id}}</td>\r\n         <td>{{user.title}}</td>\r\n         <td>{{user.body}}</td>\r\n        </tr>-->\r\n</table>\r\n<div class=\"bottomPage row\">\r\n    <div class=\"col-md-2\">\r\n    </div>\r\n    <div class=\"col-md-5\"></div>\r\n    <div class=\"paginationtop col-md-5\">\r\n        <div class=\"row\">\r\n            <div class=\"col-md-2\"></div>\r\n            <div class=\"col-md-6\">Showing Page <span class=\"pageValue\"><span class=\"leftArrow\"></span>1<span class=\"rightArrow\"></span></span> of <span class=\"totalPages\">110</span></div>\r\n        <div dropdown class=\"dropdown itemCount col-md-4\"><span>View \r\n            <button dropdownToggle type=\"button\" class=\"btn dropdown-toggle btn-default\" data-toggle=\"dropdown\" role=\"button\" title=\"Relish\" aria-expanded=\"false\">\r\n                <span>1\r\n                    <span class=\"caret\"></span>\r\n                </span>\r\n            </button>\r\n        </span> Items\r\n        <div>\r\n                <ul class=\"dropdown-menu\" *dropdownMenu>\r\n                        <li>1</li><li>2</li><li>3</li><li>4</li><li>5</li><li>6</li><li>7</li><li>8</li><li>9</li><li>10</li>\r\n                    </ul> \r\n            </div> \r\n        </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n</div>\r\n</div>"

/***/ }),

/***/ "./src/app/dashboard/dashboard.component.ts":
/*!**************************************************!*\
  !*** ./src/app/dashboard/dashboard.component.ts ***!
  \**************************************************/
/*! exports provided: DashBoardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashBoardComponent", function() { return DashBoardComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var DashBoardComponent = /** @class */ (function () {
    function DashBoardComponent() {
    }
    DashBoardComponent.prototype.ngOnInit = function () {
        this.loggedName = sessionStorage.getItem("fullName");
        //alert(this.loggedName);
    };
    DashBoardComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'dashboard',
            template: __webpack_require__(/*! ./dashboard.html */ "./src/app/dashboard/dashboard.html"),
            styles: [__webpack_require__(/*! ./dashboard.style.css */ "./src/app/dashboard/dashboard.style.css")]
        })
    ], DashBoardComponent);
    return DashBoardComponent;
}());



/***/ }),

/***/ "./src/app/dashboard/dashboard.html":
/*!******************************************!*\
  !*** ./src/app/dashboard/dashboard.html ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<header class=\"dashBoardHead row\">\r\n    <div class=\"col-md-2 logoDashBoard\">\r\n        <span>Banking Application</span>\r\n        </div>\r\n<nav class=\"col-md-7 dashBoardNav\">\r\n    <ul>\r\n            <li><a [routerLink]=\"['/dashboard']\">Home</a></li>\r\n            <li><a [routerLink]=\"['/dashboard', {outlets: {'dashboardRoute': ['customers']}}]\" skipLocationChange>Customers</a></li>\r\n            <li><a [routerLink]=\"['/dashboard', {outlets: {'dashboardRoute': ['invoices']}}]\" skipLocationChange>Invoices</a></li>\r\n            <li><a [routerLink]=\"['/auditLogs', {outlets: {'dashboardRoute': ['auditLogs']}}]\">Audit Logs</a></li>\r\n            <li><a [routerLink]=\"['/reports', {outlets: {'dashboardRoute': ['reports']}}]\">Reports</a></li>\r\n            <li><a [routerLink]=\"['/bulkUploads', {outlets: {'dashboardRoute': ['bulkUploads']}}]\">Bulk Uploads</a></li>\r\n        </ul>\r\n    </nav>\r\n    <div class=\"col-md-3 topLinks row\">\r\n        <div class=\"dropdown col-md-7\" dropdown>\r\n        <div>Welcome, <button class=\"btn btn-default dropdown-toggle userNameHolder\" dropdownToggle type=\"button\" id=\"menu1\" data-toggle=\"dropdown\">{{loggedName}}<span class=\"caret\"></span></button>\r\n            <ul class=\"dropdown-menu\" *dropdownMenu>\r\n                    <li>Change Password</li>\r\n                </ul>        \r\n        </div>\r\n        </div>\r\n        <div class=\"col-md-1 zeroPad\" >\r\n            <a class=\"notifications\">\r\n                <span class=\"notificationsText\">7</span>\r\n            </a>\r\n        </div>\r\n        <div class=\"col-md-3\"><button class=\"secondaryButtonBlue\" name=\"dashLogout\">Logout</button></div>\r\n    </div>\r\n</header>\r\n    <div class=\"dashRouteBox\"><router-outlet name='dashboardRoute'></router-outlet></div>\r\n    <footer>\r\n        Copyright &copy; 2001 - 2018 Aetna Inc.\r\n    </footer>\r\n    "

/***/ }),

/***/ "./src/app/dashboard/dashboard.style.css":
/*!***********************************************!*\
  !*** ./src/app/dashboard/dashboard.style.css ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "nav{\r\n    text-align:center;\r\n    height:100%;\r\n    padding-top:23px;\r\n  }\r\n  nav ul{\r\n    margin:0 10px !important;\r\n    height:100%;\r\n    padding:0 0 0 0;\r\n  }\r\n  nav ul li{\r\n    display:inline-block;\r\n    margin:0 10px !important;\r\n    font-size:12px;\r\n    height:100%;\r\n  }\r\n  nav ul li a{\r\n    padding-left:24px;\r\n    text-transform: uppercase;\r\n    color:#8a808e;\r\n    display:block;\r\n    height:94%;\r\n    background-repeat: no-repeat;\r\n    text-decoration: none;\r\n    font-weight: 500;\r\n    padding-top: 2px;\r\n  }\r\n  nav ul li a:hover{\r\n    color:#7a3090;\r\n    border-bottom:3px solid #cf1c71;\r\n  }\r\n  header div,nav{\r\n    margin:0 0 0 0;\r\n  }\r\n  .dashBoardHead{\r\n    align-items: center;\r\n  }\r\n  .logoDashBoard{\r\n    margin-top:-15px !important;\r\n  }\r\n  .logoDashBoard span{\r\n    padding-top:27px;\r\n    padding-left:25%;\r\n    display:block;\r\n    font-size:14px;\r\n  }\r\n  .topLinks{\r\n    padding-top:4px;\r\n    font-size:14px;\r\n  }\r\n  .topLinks p{\r\n    display: inline-block;\r\n  }\r\n  .userNameHolder{\r\n    color:#cf1c71;\r\n    font-weight: bold;\r\n    border:none;\r\n    background:none;\r\n    font-size:14px;\r\n    display:inline-block;\r\n    margin:0px;\r\n    padding:0px;\r\n    vertical-align: top;\r\n  }\r\n  .topLinks ul li{\r\n    font-size:14px;\r\n    padding:0 8px;\r\n  }\r\n  .zeroPad{\r\n    padding:0 !important;\r\n  }\r\n  /*notification pointer*/\r\n  .notifications{\r\n    display: block;\r\n     width:25px;\r\n    height: 20px;\r\n    cursor:pointer;\r\n  }\r\n  .notifications .notificationsText {\r\n    width:25px;\r\n    height: 20px;\r\n    background:#7a3090;\r\n    color: #fff;\r\n    text-align: center;\r\n    position: absolute;\r\n}\r\n  .notifications .notificationsText::after {\r\n    content: \"\";\r\n    position: absolute;\r\n    top: 100%;\r\n    left: 40%;\r\n    margin-left: -5px;\r\n    border-top: 8px solid #7a3090;\r\n    border-right: 8px solid transparent;\r\n   }\r\n"

/***/ }),

/***/ "./src/app/dashboard/dashboardBody/dashboardBody.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/dashboard/dashboardBody/dashboardBody.component.ts ***!
  \********************************************************************/
/*! exports provided: dashboardbody */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "dashboardbody", function() { return dashboardbody; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var dashboardbody = /** @class */ (function () {
    function dashboardbody() {
    }
    dashboardbody = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'dashBody',
            template: "<h2>DashBoard my</h2>"
        })
    ], dashboardbody);
    return dashboardbody;
}());



/***/ }),

/***/ "./src/app/login/login.component.ts":
/*!******************************************!*\
  !*** ./src/app/login/login.component.ts ***!
  \******************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _serverData_login_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../serverData/login.service */ "./src/app/serverData/login.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var LoginComponent = /** @class */ (function () {
    function LoginComponent(builder, router, userLoginService) {
        this.builder = builder;
        this.router = router;
        this.userLoginService = userLoginService;
        this.statusMessage = "";
        this.statusError = false;
        //form controls
        this.username = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]('', [
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required,
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].minLength(7),
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].maxLength(7)
        ]);
        this.password = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"]('', [
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required
        ]);
        //form values
        this.loginForm = this.builder.group({
            username: this.username,
            password: this.password
        });
    }
    LoginComponent.prototype.login = function () {
        var _this = this;
        /* this.router.navigate(["dashboard"]);
          this.userLoginService.login(this.loginForm.value.username,this.loginForm.value.password).subscribe(data =>{
          this.statusData = data;
          console.log(this.statusData.username);
          },(error)=>{
            this.statusMessage = 'Error Ouccured';
            alert("here")
          });*/
        if (this.loginForm.valid) {
            this.userLoginService.login(this.loginForm.value.username, this.loginForm.value.password).subscribe(function (data) {
                _this.statusData = data;
                sessionStorage.setItem("accessToken", _this.statusData.accesToken);
                sessionStorage.setItem("username", _this.loginForm.value.username);
                _this.router.navigate(["dashboard"]);
            }, function (error) {
                _this.statusMessage = error.headers.get('status-description');
                _this.statusError = true;
            });
        }
    };
    LoginComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'login',
            template: __webpack_require__(/*! ./login.html */ "./src/app/login/login.html"),
            styles: [__webpack_require__(/*! ./login.style.css */ "./src/app/login/login.style.css")]
        }),
        __metadata("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _serverData_login_service__WEBPACK_IMPORTED_MODULE_3__["loginService"]])
    ], LoginComponent);
    return LoginComponent;
}());



/***/ }),

/***/ "./src/app/login/login.html":
/*!**********************************!*\
  !*** ./src/app/login/login.html ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"loginSection\">\r\n        <div>\r\n            <div class=\"aetnaLogo\"></div>\r\n                <section>\r\n                    <div class=\"loginLogo\"></div>\r\n                    <h1>Banking Application</h1>\r\n                    <form class=\"loginBody\" [formGroup]=\"loginForm\" (ngSubmit)=\"login()\">\r\n                        <div>\r\n                            <input placeholder=\"UserName\" [ngClass]=\"{'inputError':!username.valid && username.touched}\" name=\"username\" #uname [formControl]=\"username\" type=\"text\">\r\n                            <p class=\"error\" [hidden]=\"username.valid || username.untouched\">\r\n                                    <span [hidden]=\"!username.hasError('minlength')\">\r\n                                            Username must have 7 characters\r\n                                        </span>\r\n                                    <span [hidden]=\"!username.hasError('maxlength')\">\r\n                                            Username must have 7 characters\r\n                                    </span>\r\n                                <span [hidden]=\"!username.hasError('required')\">\r\n                                    Username is required\r\n                                </span>\r\n                            </p>\r\n                        </div>\r\n                        <div>\r\n                            <input type=\"password\" [ngClass]=\"{'inputPwdError':!password.valid && password.touched}\" name=\"userpassword\" #upwrd [formControl]=\"password\" placeholder=\"Password\">\r\n                            <p [hidden]=\"password.valid || password.untouched\">\r\n                                <span class=\"error\" [hidden]=\"!password.hasError('required')\">\r\n                                    Password is required\r\n                                </span>\r\n                            </p>\r\n                        </div>\r\n                        <div>\r\n                            <button [disabled]=\"!loginForm.valid\">LOGIN</button>\r\n                            <p class=\"error\" [hidden]=\"!statusError\">\r\n                                {{statusMessage}}\r\n                            </p>\r\n                            <!--<p class=\"error\" [hidden]=\"!usernameerror\">\r\n                                    {{invalidStatusText}}\r\n                                </p>\r\n                            <p class=\"error\" [hidden]=\"!noaccess\">\r\n                                    {{invalidAccessText}}\r\n                                </p>-->\r\n                        </div>\r\n                    </form>\r\n            </section>\r\n            <p>{{statusMessage}}\r\n\r\n            </p>\r\n            <div class=\"copyright\">\r\n                Copyright &copy; 2001-2018 Aetna Inc.\r\n            </div>\r\n        </div>\r\n    </div>"

/***/ }),

/***/ "./src/app/login/login.style.css":
/*!***************************************!*\
  !*** ./src/app/login/login.style.css ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\nh1 {\r\n    color:#383838;\r\n    font-size: 24px;\r\n    font-weight:normal;\r\n    margin:20px 0;\r\n  }\r\n  section{\r\n     width: 429px;\r\n    margin: 25px auto;\r\n    border-radius: 17px;\r\n    padding: 3% 0;\r\n    text-align: center;\r\n    background-color: #fff;\r\n    box-shadow: 1px 1px 27px 0px;\r\n  }\r\n  section input,section button{\r\n      border-radius:4px;\r\n      border:1px solid #000;\r\n      height:30px;\r\n      padding-left:4px;\r\n      width:76%;\r\n  }\r\n  .loginBody div{\r\n      margin:7px 10px;\r\n      padding:0px !important\r\n  }\r\n  .loginBody input,.loginBody button{\r\n      width:76%;\r\n      height: 40px;\r\n      border-radius: 20px;\r\n      padding: 0 15px;\r\n  }\r\n  .loginBody p{\r\n      margin:4px 0 0 0;\r\n  }\r\n  .loginBody input[type=\"text\"],.loginBody input[type=\"password\"]{\r\n      background-repeat: no-repeat;\r\n      background-position: right;\r\n      background-position: 93% 51%;\r\n      background-size: 6%;\r\n      border:1px solid #e1e1e1;\r\n      color:#767474;\r\n      font-size:14px;\r\n  }\r\n  .loginBody button{\r\n      padding:0px;\r\n      width:76%;\r\n      background-color:#d8176e;\r\n      color:#fff;\r\n      border:none;\r\n      letter-spacing: 4px;\r\n      font-size: 14px;\r\n  }\r\n  .loginBody div {\r\n      margin: 2% 0 !important;\r\n      height:65px;\r\n  }\r\n  .copyright{\r\n      margin:0 auto;\r\n      text-align:center;\r\n      color:white;\r\n      font-size:12px;\r\n      margin-top:15px;\r\n  }\r\n  .error{\r\n      color:#e42929;\r\n      margin:5px 0;\r\n      font-weight:bold;\r\n      font-size:14px;\r\n  }\r\n  button:disabled{\r\n      opacity:0.5;\r\n  }\r\n  .inputError,.inputPwdError{\r\n      border:2px solid #e42929 !important;\r\n  }"

/***/ }),

/***/ "./src/app/serverData/customerDetails.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/serverData/customerDetails.service.ts ***!
  \*******************************************************/
/*! exports provided: customerDetailsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "customerDetailsService", function() { return customerDetailsService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm5/add/operator/map.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var customerDetailsService = /** @class */ (function () {
    function customerDetailsService(http) {
        this.http = http;
    }
    customerDetailsService.prototype.getUsers = function () {
        var reqheaders = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]();
        reqheaders.append("Accept", "application/json");
        reqheaders.append("AccessToken", sessionStorage.getItem("accessToken"));
        reqheaders.append("UserName", sessionStorage.getItem("username"));
        var options = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["RequestOptions"]({ headers: reqheaders });
        return this.http.get("https://jsonplaceholder.typicode.com/posts", options)
            .map(function (res) { return res.json(); });
    };
    customerDetailsService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"]])
    ], customerDetailsService);
    return customerDetailsService;
}());

//https://jsonplaceholder.typicode.com/posts  http://10.85.82.75:9080/abaService/rest/customers
//https://devinternal.aetna.com/abaService2/rest/customers


/***/ }),

/***/ "./src/app/serverData/login.service.ts":
/*!*********************************************!*\
  !*** ./src/app/serverData/login.service.ts ***!
  \*********************************************/
/*! exports provided: loginService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "loginService", function() { return loginService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/Observable */ "./node_modules/rxjs-compat/_esm5/Observable.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm5/add/operator/map.js");
/* harmony import */ var rxjs_add_operator_catch__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/catch */ "./node_modules/rxjs-compat/_esm5/add/operator/catch.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var loginService = /** @class */ (function () {
    function loginService(http) {
        this.http = http;
    }
    loginService.prototype.login = function (username, userpwd) {
        var headers = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["Headers"]({ 'Content-Type': 'application/json' });
        var loginData = {
            "username": username,
            "password": userpwd
        };
        //loginData = loginData.toJSON();
        var options = new _angular_http__WEBPACK_IMPORTED_MODULE_1__["RequestOptions"]({ headers: headers }); // http://10.85.47.90:9092/abaService/rest/login  https://jsonplaceholder.typicode.com/posts  http://10.85.82.75:9080/abaService/rest/login
        return this.http.post("https://devinternal.aetna.com/abaService2/rest/login", loginData, options)
            .map(function (res) { return res.json(); })
            .catch(this.handleError);
    };
    loginService.prototype.handleError = function (error) {
        console.error(error);
        return rxjs_Observable__WEBPACK_IMPORTED_MODULE_2__["Observable"].throw(error);
    };
    loginService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_1__["Http"]])
    ], loginService);
    return loginService;
}());

//https://devinternal.aetna.com/abaService2/rest/login


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\540455\Desktop\angularWorkSpace\WorkSpace1\quickstart-master\quickstart-master\workspaceServe\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map