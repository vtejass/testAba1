export var defaultMonthOptions = {
    width: 7,
    height: 6
};
//# sourceMappingURL=_defaults.js.map