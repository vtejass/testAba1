import { MonthViewOptions } from '../models/index';
export declare const defaultMonthOptions: MonthViewOptions;
