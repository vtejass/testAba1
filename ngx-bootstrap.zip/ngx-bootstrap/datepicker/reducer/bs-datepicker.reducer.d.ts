import { BsDatepickerState } from './bs-datepicker.state';
import { Action } from '../../mini-ngrx/index';
export declare function bsDatepickerReducer(state: BsDatepickerState, action: Action): BsDatepickerState;
