import { DayViewModel } from '../../models/index';
export declare class BsDatepickerDayDecoratorComponent {
    day: DayViewModel;
}
