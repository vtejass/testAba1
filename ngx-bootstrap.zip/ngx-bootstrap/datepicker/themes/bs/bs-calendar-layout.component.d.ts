export declare class BsCalendarLayoutComponent {
}
