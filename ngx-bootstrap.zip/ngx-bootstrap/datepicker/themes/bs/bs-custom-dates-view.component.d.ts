export interface BsCustomDates {
    label: string;
    value: Date | Date[];
}
export declare class BsCustomDatesViewComponent {
    isCustomRangeShown: true;
    ranges: BsCustomDates[];
}
