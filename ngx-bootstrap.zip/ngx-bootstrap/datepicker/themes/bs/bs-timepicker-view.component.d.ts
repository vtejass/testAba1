export declare class BsTimepickerViewComponent {
    ampm: string;
    hours: number;
    minutes: number;
}
