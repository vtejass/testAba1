import { BsDatepickerViewMode } from '../models/index';
export declare function canSwitchMode(mode: BsDatepickerViewMode): boolean;
