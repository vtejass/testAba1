import { DatepickerFormatOptions, YearsCalendarViewModel } from '../models/index';
export declare const yearsPerCalendar: number;
export declare function formatYearsCalendar(viewDate: Date, formatOptions: DatepickerFormatOptions): YearsCalendarViewModel;
