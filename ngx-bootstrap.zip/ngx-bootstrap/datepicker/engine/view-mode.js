export function canSwitchMode(mode) {
    return true;
}
//# sourceMappingURL=view-mode.js.map