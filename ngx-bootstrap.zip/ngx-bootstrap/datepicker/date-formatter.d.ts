export declare class DateFormatter {
    format(date: Date, format: string, locale: string): string;
}
