import { ModuleWithProviders } from '@angular/core';
export declare class DatepickerModule {
    static forRoot(): ModuleWithProviders;
}
