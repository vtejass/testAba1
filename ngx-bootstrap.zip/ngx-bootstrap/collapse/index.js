export { CollapseDirective } from './collapse.directive';
export { CollapseModule } from './collapse.module';
//# sourceMappingURL=index.js.map