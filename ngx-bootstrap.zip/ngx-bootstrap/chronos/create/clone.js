// fastest way to clone date
// https://jsperf.com/clone-date-object2
export function cloneDate(date) {
    return new Date(date.getTime());
}
//# sourceMappingURL=clone.js.map