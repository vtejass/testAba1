import { DateInput } from '../test/chain';
export declare function parseDate(input: DateInput, format?: string | string[], localeKey?: string, strict?: boolean, isUTC?: boolean): Date;
