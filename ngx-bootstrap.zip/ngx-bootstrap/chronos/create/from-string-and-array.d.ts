import { DateParsingConfig } from './parsing.types';
export declare function configFromStringAndArray(config: DateParsingConfig): DateParsingConfig;
