export function absCeil(number) {
    return number < 0 ? Math.floor(number) : Math.ceil(number);
}
//# sourceMappingURL=abs-ceil.js.map