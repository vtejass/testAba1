import { UnitOfTime } from '../types';
export declare function startOf(date: Date, unit: UnitOfTime, isUTC?: boolean): Date;
export declare function endOf(date: Date, unit: UnitOfTime, isUTC?: boolean): Date;
