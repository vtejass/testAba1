export declare function getQuarter(date: Date, isUTC?: boolean): number;
export declare function setQuarter(date: Date, quarter: number, isUTC?: boolean): Date;
