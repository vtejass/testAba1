// place in new Date([array])
export var YEAR = 0;
export var MONTH = 1;
export var DATE = 2;
export var HOUR = 3;
export var MINUTE = 4;
export var SECOND = 5;
export var MILLISECOND = 6;
export var WEEK = 7;
export var WEEKDAY = 8;
//# sourceMappingURL=constants.js.map