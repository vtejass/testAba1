export declare function getDayOfYear(date: Date, isUTC?: boolean): number;
export declare function setDayOfYear(date: Date, input: number): Date;
