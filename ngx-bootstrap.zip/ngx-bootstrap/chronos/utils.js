export function mod(n, x) {
    return (n % x + x) % x;
}
export function absFloor(num) {
    return num < 0 ? Math.ceil(num) || 0 : Math.floor(num);
}
//# sourceMappingURL=utils.js.map